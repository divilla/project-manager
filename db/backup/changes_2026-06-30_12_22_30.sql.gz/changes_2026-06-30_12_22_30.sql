--
-- PostgreSQL database dump
--

\restrict AWzmTtFPDl0T1M7gZPeHC1THnBquRbyprPBPR4aiBWITjp5Jwui66UqXNZsfM04

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.test_case DROP CONSTRAINT test_case_pkey;
ALTER TABLE ONLY public.test_case_history DROP CONSTRAINT test_case_history_pkey;
ALTER TABLE ONLY public.change DROP CONSTRAINT task_pkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_pkey;
ALTER TABLE ONLY public.epic DROP CONSTRAINT epic_pkey;
ALTER TABLE ONLY public.epic_history DROP CONSTRAINT epic_history_pkey;
ALTER TABLE ONLY public.change_type DROP CONSTRAINT change_type_pkey;
ALTER TABLE ONLY public.change_phase DROP CONSTRAINT change_phase_pkey;
ALTER TABLE ONLY public.change_history DROP CONSTRAINT change_history_pkey;
DROP VIEW public.vw_foreign_key;
DROP VIEW public.vw_epic;
DROP TABLE public.test_case_history;
DROP TABLE public.test_case;
DROP TABLE public.project;
DROP TABLE public.epic_history;
DROP TABLE public.epic;
DROP TABLE public.change_type;
DROP TABLE public.change_phase;
DROP TABLE public.change_history;
DROP TABLE public.change;
DROP PROCEDURE public.sp_test_case_to_history(IN _id bigint, IN _deleted boolean);
DROP PROCEDURE public.sp_epic_to_history(IN _id bigint, IN _deleted boolean);
DROP PROCEDURE public.sp_epic_test_case_recalculate(IN _epic_id bigint);
DROP PROCEDURE public.sp_change_to_history(IN _id bigint, IN _deleted boolean);
DROP PROCEDURE public.sp_change_test_case_recalculate(IN _change_id bigint);
DROP PROCEDURE public.sp_change_insert(IN _project_id bigint, IN _change_types text[], IN _epic_id bigint, IN _title text, IN _requirement_body text);
--
-- Name: sp_change_insert(bigint, text[], bigint, text, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_change_insert(IN _project_id bigint, IN _change_types text[], IN _epic_id bigint, IN _title text, IN _requirement_body text)
    LANGUAGE plpgsql
    AS $$
declare
    _ref smallint;
    _slug text;
begin
    update public.project set last_ref=last_ref+1 where id=_project_id returning last_ref into _ref;
    _title=regexp_replace(trim(_title), '\s+', ' ', 'g');
    _slug=regexp_replace(lower(_title), '\s+', '_', 'g');
    _slug=concat(lpad(_ref::text, 6, '0'), '-', _slug);
    insert into public.change (
        ref, slug, project_id, change_types, epic_id, title, requirement_body
    )
    values (
        _ref, _slug, _project_id, _change_types, _epic_id, _title, _requirement_body
    );
end;
$$;


ALTER PROCEDURE public.sp_change_insert(IN _project_id bigint, IN _change_types text[], IN _epic_id bigint, IN _title text, IN _requirement_body text) OWNER TO postgres;

--
-- Name: sp_change_test_case_recalculate(bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_change_test_case_recalculate(IN _change_id bigint)
    LANGUAGE plpgsql
    AS $$
declare
    _epic_id bigint;
    _done_tc smallint;
    _total_tc smallint;
begin
    select count(*) into _done_tc from test_case where change_id=_change_id and done=true;
    select count(*) into _total_tc from test_case where change_id=_change_id;

    update public.change
    set
        done_tc=_done_tc,
        total_tc=_total_tc,
        modified=now()
    where id=_change_id;

    select epic_id into _epic_id from change where id=_change_id;
    call sp_epic_test_case_recalculate(_epic_id);
end;
$$;


ALTER PROCEDURE public.sp_change_test_case_recalculate(IN _change_id bigint) OWNER TO postgres;

--
-- Name: sp_change_to_history(bigint, boolean); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_change_to_history(IN _id bigint, IN _deleted boolean)
    LANGUAGE plpgsql
    AS $$
begin
    insert into public.change_history (
        id, version, project_id, epic_id, change_phase, change_types, title, requirement_body, pull_request_body, pull_request_url, closed, modified, deleted
    )
    select
        id, version, project_id, epic_id, change_phase, change_types, title, requirement_body, pull_request_body, pull_request_url, closed, modified, _deleted
    from public.change
    where id = _id;
end;
$$;


ALTER PROCEDURE public.sp_change_to_history(IN _id bigint, IN _deleted boolean) OWNER TO postgres;

--
-- Name: sp_epic_test_case_recalculate(bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_epic_test_case_recalculate(IN _epic_id bigint)
    LANGUAGE plpgsql
    AS $$
declare
    _done_tc smallint;
    _total_tc smallint;
begin
    if _epic_id is null then return; end if;

    select
        coalesce(sum(done_tc), 0),
        coalesce(sum(total_tc), 0)
    into
        _done_tc,
        _total_tc
    from public.change
    where epic_id=_epic_id;

    update public.epic
    set
        done_tc=_done_tc,
        total_tc=_total_tc
    where id=_epic_id;
end;
$$;


ALTER PROCEDURE public.sp_epic_test_case_recalculate(IN _epic_id bigint) OWNER TO postgres;

--
-- Name: sp_epic_to_history(bigint, boolean); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_epic_to_history(IN _id bigint, IN _deleted boolean)
    LANGUAGE plpgsql
    AS $$
begin
    insert into public.epic_history (
        id, version, project_id, name, modified, deleted
    )
    select
        id, version, project_id, name, modified, _deleted
    from public.epic
    where id = _id;
end;
$$;


ALTER PROCEDURE public.sp_epic_to_history(IN _id bigint, IN _deleted boolean) OWNER TO postgres;

--
-- Name: sp_test_case_to_history(bigint, boolean); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_test_case_to_history(IN _id bigint, IN _deleted boolean)
    LANGUAGE plpgsql
    AS $$
begin
    insert into public.test_case_history (
        id, version, change_id, scenario, modified, deleted
    )
    select
        id, version, change_id, scenario, modified, _deleted
    from public.test_case
    where id = _id;
end;
$$;


ALTER PROCEDURE public.sp_test_case_to_history(IN _id bigint, IN _deleted boolean) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: change; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change (
    id bigint NOT NULL,
    version smallint DEFAULT 0 NOT NULL,
    ref smallint DEFAULT 0 NOT NULL,
    slug text DEFAULT ''::text NOT NULL,
    project_id bigint NOT NULL,
    change_phase text DEFAULT 'backlog'::text NOT NULL,
    change_types text[] NOT NULL,
    epic_id bigint,
    title text NOT NULL,
    requirement_body text,
    pull_request_body text,
    pull_request_url text,
    closed boolean DEFAULT false NOT NULL,
    done_tc smallint DEFAULT 0 NOT NULL,
    total_tc smallint DEFAULT 0 NOT NULL,
    completed smallint GENERATED ALWAYS AS (COALESCE(((done_tc / NULLIF(total_tc, 0)))::integer, 0)),
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.change OWNER TO postgres;

--
-- Name: change_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change_history (
    id bigint NOT NULL,
    version smallint NOT NULL,
    project_id bigint NOT NULL,
    change_phase text NOT NULL,
    change_types text[] NOT NULL,
    epic_id bigint,
    title text NOT NULL,
    requirement_body text,
    pull_request_body text,
    pull_request_url text,
    closed boolean NOT NULL,
    modified timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.change_history OWNER TO postgres;

--
-- Name: change_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.change ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.change_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: change_phase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change_phase (
    slug text DEFAULT 'backlog'::text NOT NULL,
    priority integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.change_phase OWNER TO postgres;

--
-- Name: change_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change_type (
    slug text DEFAULT 'feature'::text NOT NULL,
    priority integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.change_type OWNER TO postgres;

--
-- Name: epic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.epic (
    id bigint NOT NULL,
    version smallint DEFAULT 0 NOT NULL,
    project_id bigint NOT NULL,
    name text NOT NULL,
    done_tc smallint DEFAULT 0 NOT NULL,
    total_tc smallint DEFAULT 0 NOT NULL,
    completed smallint GENERATED ALWAYS AS (COALESCE(((((100 * done_tc) / NULLIF(total_tc, 0)))::smallint)::integer, 0)) STORED,
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.epic OWNER TO postgres;

--
-- Name: epic_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.epic_history (
    id bigint NOT NULL,
    version smallint NOT NULL,
    project_id bigint NOT NULL,
    name text NOT NULL,
    modified timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.epic_history OWNER TO postgres;

--
-- Name: epic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.epic ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.epic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint NOT NULL,
    name text NOT NULL,
    last_ref smallint DEFAULT 0 NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.project ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: test_case; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_case (
    id bigint NOT NULL,
    version smallint DEFAULT 0 NOT NULL,
    change_id bigint NOT NULL,
    scenario text NOT NULL,
    done boolean DEFAULT false NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_case OWNER TO postgres;

--
-- Name: test_case_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_case_history (
    id bigint NOT NULL,
    version smallint NOT NULL,
    change_id bigint NOT NULL,
    scenario text NOT NULL,
    modified timestamp with time zone NOT NULL,
    deleted boolean NOT NULL
);


ALTER TABLE public.test_case_history OWNER TO postgres;

--
-- Name: test_case_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.test_case ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.test_case_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vw_epic; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_epic AS
 SELECT e.id,
    e.version,
    e.project_id,
    e.name,
    e.done_tc,
    e.total_tc,
    e.completed,
    (count(c.*))::integer AS change_count,
    e.created,
    e.modified
   FROM (public.epic e
     LEFT JOIN public.change c ON ((e.id = c.epic_id)))
  GROUP BY e.id, e.version, e.project_id, e.name, e.done_tc, e.total_tc, e.completed, e.created, e.modified
  ORDER BY e.name;


ALTER VIEW public.vw_epic OWNER TO postgres;

--
-- Name: vw_foreign_key; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_foreign_key AS
 SELECT conname AS foreign_key_name,
    (conrelid)::regclass AS table_name,
    (confrelid)::regclass AS referenced_table
   FROM pg_constraint
  WHERE ((contype = 'f'::"char") AND (connamespace = ('public'::regnamespace)::oid))
  ORDER BY (conrelid)::regclass, conname;


ALTER VIEW public.vw_foreign_key OWNER TO postgres;

--
-- Data for Name: change; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change (id, version, ref, slug, project_id, change_phase, change_types, epic_id, title, requirement_body, pull_request_body, pull_request_url, closed, done_tc, total_tc, created, modified) FROM stdin;
\.


--
-- Data for Name: change_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change_history (id, version, project_id, change_phase, change_types, epic_id, title, requirement_body, pull_request_body, pull_request_url, closed, modified, deleted) FROM stdin;
\.


--
-- Data for Name: change_phase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change_phase (slug, priority) FROM stdin;
backlog	0
progress	1
review	2
staging	3
production	4
rejected	5
\.


--
-- Data for Name: change_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change_type (slug, priority) FROM stdin;
feature	0
fix	1
refactor	2
upgrade	3
chore	4
docs	5
test	6
ci	7
security	8
migration	9
revert	10
spike	11
\.


--
-- Data for Name: epic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.epic (id, version, project_id, name, done_tc, total_tc, created, modified) FROM stdin;
1	0	1	Platform Foundation	2	3	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
2	0	1	Project Workspace	1	1	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
3	0	1	Completeness Engine	0	2	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
\.


--
-- Data for Name: epic_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.epic_history (id, version, project_id, name, modified, deleted) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, name, last_ref, created, modified) FROM stdin;
\.


--
-- Data for Name: test_case; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_case (id, version, change_id, scenario, done, created, modified) FROM stdin;
1	0	1	Schema can be rebuilt from init and seed scripts.	f	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
2	0	2	Database health check reports availability.	t	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
3	0	2	Health endpoint reports API availability.	t	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
4	0	4	Create returns the generated project identifier.	t	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
5	0	5	Done toggles update change completeness.	f	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
6	0	6	Test case create returns recalculated change data.	f	2026-06-30 03:56:35.615584+02	2026-06-30 03:56:35.615584+02
\.


--
-- Data for Name: test_case_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_case_history (id, version, change_id, scenario, modified, deleted) FROM stdin;
\.


--
-- Name: change_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.change_id_seq', 1, false);


--
-- Name: epic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.epic_id_seq', 3, true);


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.project_id_seq', 1, false);


--
-- Name: test_case_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_case_id_seq', 6, true);


--
-- Name: change_history change_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_history
    ADD CONSTRAINT change_history_pkey PRIMARY KEY (id, version);


--
-- Name: change_phase change_phase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_phase
    ADD CONSTRAINT change_phase_pkey PRIMARY KEY (slug);


--
-- Name: change_type change_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_type
    ADD CONSTRAINT change_type_pkey PRIMARY KEY (slug);


--
-- Name: epic_history epic_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.epic_history
    ADD CONSTRAINT epic_history_pkey PRIMARY KEY (id, version);


--
-- Name: epic epic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.epic
    ADD CONSTRAINT epic_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: change task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: test_case_history test_case_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_case_history
    ADD CONSTRAINT test_case_history_pkey PRIMARY KEY (id, version);


--
-- Name: test_case test_case_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_case
    ADD CONSTRAINT test_case_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict AWzmTtFPDl0T1M7gZPeHC1THnBquRbyprPBPR4aiBWITjp5Jwui66UqXNZsfM04

