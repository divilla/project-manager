--
-- PostgreSQL database dump
--

\restrict hNrQYYnCxgtpkjlNVkZm3lpf4pKR2HehpQR3MEaQg87CXengO7i0krD86n4o0BM

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.change_type DROP CONSTRAINT task_type_pkey;
ALTER TABLE ONLY public.change DROP CONSTRAINT task_pkey;
ALTER TABLE ONLY public.change_phase DROP CONSTRAINT task_phase_pkey;
ALTER TABLE ONLY public.change_history DROP CONSTRAINT task_history_pkey;
ALTER TABLE ONLY public.requirement DROP CONSTRAINT requirement_pkey;
ALTER TABLE ONLY public.requirement_history DROP CONSTRAINT requirement_history_pkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_pkey;
ALTER TABLE ONLY public.epic DROP CONSTRAINT epic_pkey;
ALTER TABLE ONLY public.epic_history DROP CONSTRAINT epic_history_pkey;
DROP VIEW public.vw_project;
DROP VIEW public.vw_change;
DROP TABLE public.requirement_history;
DROP TABLE public.requirement;
DROP TABLE public.project;
DROP TABLE public.epic_history;
DROP TABLE public.epic;
DROP TABLE public.change_type;
DROP TABLE public.change_phase;
DROP TABLE public.change_history;
DROP TABLE public.change;
DROP PROCEDURE public.sp_requirement_to_history(IN _id bigint, IN _deleted boolean);
DROP PROCEDURE public.sp_change_to_history(IN _id bigint, IN _deleted boolean);
DROP PROCEDURE public.sp_change_requirement_recalculate(IN _change_id bigint);
--
-- Name: sp_change_requirement_recalculate(bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_change_requirement_recalculate(IN _change_id bigint)
    LANGUAGE plpgsql
    AS $$
declare
    _epic_id bigint;
    _done_req smallint;
    _total_req smallint;
begin
    loop
        select count(*) into _done_req from requirement where change_id=_change_id and done=true;
        select count(*) into _total_req from requirement where change_id=_change_id;

        update public.change
        set
            done_req=_done_req,
            total_req=_total_req
        where id=_change_id;

        select epic_id into _epic_id from change where id=_change_id;
        select
            coalesce(sum(done_req), 0),
            coalesce(sum(total_req), 0)
        into
            _done_req,
            _total_req
        from public.change
        where epic_id=_epic_id;

        update public.epic
        set
            done_req=_done_req,
            total_req=_total_req
        where id=_epic_id;
    end loop;
end;
$$;


ALTER PROCEDURE public.sp_change_requirement_recalculate(IN _change_id bigint) OWNER TO postgres;

--
-- Name: sp_change_to_history(bigint, boolean); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_change_to_history(IN _id bigint, IN _deleted boolean)
    LANGUAGE plpgsql
    AS $$
begin
    insert into public.change_history (
        id, version, project_id, epic_id, change_types, title, body, modified, deleted
    )
    select
        id, version, project_id, epic_id, change_types, title, body, modified, _deleted
    from public.change
    where id = _id;
end;
$$;


ALTER PROCEDURE public.sp_change_to_history(IN _id bigint, IN _deleted boolean) OWNER TO postgres;

--
-- Name: sp_requirement_to_history(bigint, boolean); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_requirement_to_history(IN _id bigint, IN _deleted boolean)
    LANGUAGE plpgsql
    AS $$
begin
    insert into public.requirement_history (
        id, version, definition, modified, deleted
    )
    select
        id, version, definition, modified, _deleted
    from public.requirement
    where id = _id;
end;
$$;


ALTER PROCEDURE public.sp_requirement_to_history(IN _id bigint, IN _deleted boolean) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: change; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change (
    id bigint NOT NULL,
    version smallint DEFAULT 0 NOT NULL,
    project_id bigint NOT NULL,
    epic_id bigint,
    change_phase text DEFAULT 'backlog'::text NOT NULL,
    change_types text[] NOT NULL,
    title text NOT NULL,
    body text,
    closed boolean DEFAULT false NOT NULL,
    done_req smallint DEFAULT 0 NOT NULL,
    total_req smallint DEFAULT 0 NOT NULL,
    completed smallint GENERATED ALWAYS AS (COALESCE(((done_req / NULLIF(total_req, 0)))::integer, 0)),
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.change OWNER TO postgres;

--
-- Name: change_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change_history (
    id bigint NOT NULL,
    version smallint NOT NULL,
    project_id bigint NOT NULL,
    epic_id bigint NOT NULL,
    change_types text[] NOT NULL,
    title text NOT NULL,
    body text,
    modified timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.change_history OWNER TO postgres;

--
-- Name: change_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.change ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.change_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: change_phase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change_phase (
    slug text DEFAULT 'backlog'::text CONSTRAINT task_phase_slug_not_null NOT NULL,
    priority integer DEFAULT 0 CONSTRAINT task_phase_priority_not_null NOT NULL
);


ALTER TABLE public.change_phase OWNER TO postgres;

--
-- Name: change_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change_type (
    slug text DEFAULT 'task'::text CONSTRAINT task_type_slug_not_null NOT NULL,
    priority integer DEFAULT 0 CONSTRAINT task_type_priority_not_null NOT NULL
);


ALTER TABLE public.change_type OWNER TO postgres;

--
-- Name: epic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.epic (
    id bigint NOT NULL,
    version smallint NOT NULL,
    name text NOT NULL,
    done_req smallint DEFAULT 0 NOT NULL,
    total_req smallint DEFAULT 0 NOT NULL,
    completed smallint GENERATED ALWAYS AS (COALESCE(((done_req / NULLIF(total_req, 0)))::integer, 0)),
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.epic OWNER TO postgres;

--
-- Name: epic_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.epic_history (
    id bigint NOT NULL,
    version smallint NOT NULL,
    name text NOT NULL,
    modified timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.epic_history OWNER TO postgres;

--
-- Name: epic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.epic ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.epic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint NOT NULL,
    name text NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.project ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: requirement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requirement (
    id bigint NOT NULL,
    version smallint DEFAULT 0 NOT NULL,
    definition text NOT NULL,
    done boolean DEFAULT false NOT NULL,
    change_id bigint CONSTRAINT requirement_task_id_not_null NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.requirement OWNER TO postgres;

--
-- Name: requirement_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requirement_history (
    id bigint NOT NULL,
    version smallint NOT NULL,
    definition text NOT NULL,
    modified timestamp with time zone NOT NULL,
    deleted boolean NOT NULL
);


ALTER TABLE public.requirement_history OWNER TO postgres;

--
-- Name: requirement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.requirement ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.requirement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vw_change; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_change AS
 SELECT id,
    version,
    project_id,
    epic_id,
    change_phase,
    change_types,
    title,
    body,
    closed,
    done_req,
    total_req,
    COALESCE(((done_req / NULLIF(total_req, 0)))::integer, 0) AS completed,
    created,
    modified
   FROM public.change;


ALTER VIEW public.vw_change OWNER TO postgres;

--
-- Name: vw_project; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_project AS
 SELECT p.id,
    p.name,
    p.created,
    p.modified,
    count(t.*) AS task_count
   FROM (public.project p
     LEFT JOIN public.change t ON ((p.id = t.project_id)))
  GROUP BY p.id, p.name, p.created, p.modified
  ORDER BY p.id;


ALTER VIEW public.vw_project OWNER TO postgres;

--
-- Data for Name: change; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change (id, version, project_id, epic_id, change_phase, change_types, title, body, closed, done_req, total_req, created, modified) FROM stdin;
\.


--
-- Data for Name: change_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change_history (id, version, project_id, epic_id, change_types, title, body, modified, deleted) FROM stdin;
\.


--
-- Data for Name: change_phase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change_phase (slug, priority) FROM stdin;
backlog	0
progress	1
review	2
staging	3
production	4
rejected	5
\.


--
-- Data for Name: change_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change_type (slug, priority) FROM stdin;
feature	0
fix	0
refactor	0
upgrade	0
chore	0
docs	0
test	0
ci	0
security	0
migration	0
revert	0
spike	0
\.


--
-- Data for Name: epic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.epic (id, version, name, done_req, total_req, created, modified) FROM stdin;
\.


--
-- Data for Name: epic_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.epic_history (id, version, name, modified, deleted) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, name, created, modified) FROM stdin;
1	demo1	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
2	demo2	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
3	demo3	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
\.


--
-- Data for Name: requirement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requirement (id, version, definition, done, change_id, created, modified) FROM stdin;
1	0	Confirm the implementation matches the documented contract: Document incremental migration ordering.	f	19	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
2	0	Confirm the implementation matches the documented contract: Seed realistic demonstration data.	f	20	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
3	0	Add an automated test for the primary success path: Seed realistic demonstration data.	t	20	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
4	0	Confirm the implementation matches the documented contract: Seed workflow reference values.	t	21	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
5	0	Add an automated test for the primary success path: Seed workflow reference values.	t	21	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
6	0	Add an automated test for invalid input: Seed workflow reference values.	t	21	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
7	0	Confirm the implementation matches the documented contract: Define clean database bootstrap.	f	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
8	0	Add an automated test for the primary success path: Define clean database bootstrap.	f	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
9	0	Add an automated test for invalid input: Define clean database bootstrap.	f	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
10	0	Verify database changes are atomic on failure: Define clean database bootstrap.	f	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
11	0	Confirm the implementation matches the documented contract: Enable local CORS policy.	f	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
12	0	Add an automated test for the primary success path: Enable local CORS policy.	t	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
13	0	Add an automated test for invalid input: Enable local CORS policy.	f	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
14	0	Verify database changes are atomic on failure: Enable local CORS policy.	t	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
15	0	Verify the user-facing error identifies the corrective action: Enable local CORS policy.	f	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
16	0	Confirm the implementation matches the documented contract: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
17	0	Add an automated test for the primary success path: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
18	0	Add an automated test for invalid input: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
19	0	Verify database changes are atomic on failure: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
20	0	Verify the user-facing error identifies the corrective action: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
21	0	Review naming and behavior against existing project conventions: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
22	0	Confirm the implementation matches the documented contract: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
23	0	Add an automated test for the primary success path: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
24	0	Add an automated test for invalid input: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
25	0	Verify database changes are atomic on failure: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
26	0	Verify the user-facing error identifies the corrective action: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
27	0	Review naming and behavior against existing project conventions: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
28	0	Confirm repeated execution does not create duplicate state: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
29	0	Confirm the implementation matches the documented contract: Refresh workspace data.	f	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
30	0	Add an automated test for the primary success path: Refresh workspace data.	t	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
31	0	Add an automated test for invalid input: Refresh workspace data.	f	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
32	0	Verify database changes are atomic on failure: Refresh workspace data.	t	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
33	0	Verify the user-facing error identifies the corrective action: Refresh workspace data.	f	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
34	0	Review naming and behavior against existing project conventions: Refresh workspace data.	t	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
35	0	Confirm repeated execution does not create duplicate state: Refresh workspace data.	f	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
36	0	Record observable evidence that the behavior works: Refresh workspace data.	t	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
37	0	Confirm the implementation matches the documented contract: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
38	0	Add an automated test for the primary success path: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
39	0	Add an automated test for invalid input: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
40	0	Verify database changes are atomic on failure: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
41	0	Verify the user-facing error identifies the corrective action: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
42	0	Review naming and behavior against existing project conventions: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
43	0	Confirm repeated execution does not create duplicate state: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
44	0	Record observable evidence that the behavior works: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
45	0	Complete peer review of the delivered behavior: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
46	0	Confirm the implementation matches the documented contract: Render empty workspace state.	f	28	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
47	0	Confirm the implementation matches the documented contract: Select active project.	f	29	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
48	0	Add an automated test for the primary success path: Select active project.	t	29	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
49	0	Confirm the implementation matches the documented contract: Rename existing project.	t	30	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
50	0	Add an automated test for the primary success path: Rename existing project.	t	30	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
51	0	Add an automated test for invalid input: Rename existing project.	t	30	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
52	0	Confirm the implementation matches the documented contract: List project workspaces.	f	31	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
53	0	Add an automated test for the primary success path: List project workspaces.	f	31	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
54	0	Add an automated test for invalid input: List project workspaces.	f	31	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
55	0	Verify database changes are atomic on failure: List project workspaces.	f	31	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
56	0	Confirm the implementation matches the documented contract: Create project endpoint.	f	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
57	0	Add an automated test for the primary success path: Create project endpoint.	t	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
58	0	Add an automated test for invalid input: Create project endpoint.	f	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
59	0	Verify database changes are atomic on failure: Create project endpoint.	t	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
60	0	Verify the user-facing error identifies the corrective action: Create project endpoint.	f	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
61	0	Confirm the implementation matches the documented contract: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
62	0	Add an automated test for the primary success path: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
63	0	Add an automated test for invalid input: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
64	0	Verify database changes are atomic on failure: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
65	0	Verify the user-facing error identifies the corrective action: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
66	0	Review naming and behavior against existing project conventions: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
67	0	Confirm the implementation matches the documented contract: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
68	0	Add an automated test for the primary success path: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
69	0	Add an automated test for invalid input: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
70	0	Verify database changes are atomic on failure: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
71	0	Verify the user-facing error identifies the corrective action: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
72	0	Review naming and behavior against existing project conventions: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
73	0	Confirm repeated execution does not create duplicate state: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
74	0	Confirm the implementation matches the documented contract: Reject stale task update.	f	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
75	0	Add an automated test for the primary success path: Reject stale task update.	t	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
76	0	Add an automated test for invalid input: Reject stale task update.	f	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
77	0	Verify database changes are atomic on failure: Reject stale task update.	t	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
78	0	Verify the user-facing error identifies the corrective action: Reject stale task update.	f	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
79	0	Review naming and behavior against existing project conventions: Reject stale task update.	t	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
80	0	Confirm repeated execution does not create duplicate state: Reject stale task update.	f	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
81	0	Record observable evidence that the behavior works: Reject stale task update.	t	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
82	0	Confirm the implementation matches the documented contract: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
83	0	Add an automated test for the primary success path: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
84	0	Add an automated test for invalid input: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
85	0	Verify database changes are atomic on failure: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
86	0	Verify the user-facing error identifies the corrective action: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
87	0	Review naming and behavior against existing project conventions: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
88	0	Confirm repeated execution does not create duplicate state: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
89	0	Record observable evidence that the behavior works: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
90	0	Complete peer review of the delivered behavior: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
91	0	Confirm the implementation matches the documented contract: Delete task subtree.	f	37	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
92	0	Confirm the implementation matches the documented contract: Create child task.	f	38	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
93	0	Add an automated test for the primary success path: Create child task.	t	38	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
94	0	Confirm the implementation matches the documented contract: Create root task.	t	39	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
95	0	Add an automated test for the primary success path: Create root task.	t	39	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
96	0	Add an automated test for invalid input: Create root task.	t	39	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
97	0	Confirm the implementation matches the documented contract: Verify multi-level aggregation.	f	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
98	0	Add an automated test for the primary success path: Verify multi-level aggregation.	f	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
99	0	Add an automated test for invalid input: Verify multi-level aggregation.	f	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
100	0	Verify database changes are atomic on failure: Verify multi-level aggregation.	f	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
101	0	Confirm the implementation matches the documented contract: Render derived completion percentage.	f	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
102	0	Add an automated test for the primary success path: Render derived completion percentage.	t	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
103	0	Add an automated test for invalid input: Render derived completion percentage.	f	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
104	0	Verify database changes are atomic on failure: Render derived completion percentage.	t	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
105	0	Verify the user-facing error identifies the corrective action: Render derived completion percentage.	f	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
106	0	Confirm the implementation matches the documented contract: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
107	0	Add an automated test for the primary success path: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
108	0	Add an automated test for invalid input: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
109	0	Verify database changes are atomic on failure: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
110	0	Verify the user-facing error identifies the corrective action: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
111	0	Review naming and behavior against existing project conventions: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
112	0	Confirm the implementation matches the documented contract: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
113	0	Add an automated test for the primary success path: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
114	0	Add an automated test for invalid input: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
115	0	Verify database changes are atomic on failure: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
116	0	Verify the user-facing error identifies the corrective action: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
117	0	Review naming and behavior against existing project conventions: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
118	0	Confirm repeated execution does not create duplicate state: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
119	0	Confirm the implementation matches the documented contract: Edit requirement definition.	f	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
120	0	Add an automated test for the primary success path: Edit requirement definition.	t	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
121	0	Add an automated test for invalid input: Edit requirement definition.	f	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
122	0	Verify database changes are atomic on failure: Edit requirement definition.	t	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
123	0	Verify the user-facing error identifies the corrective action: Edit requirement definition.	f	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
124	0	Review naming and behavior against existing project conventions: Edit requirement definition.	t	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
125	0	Confirm repeated execution does not create duplicate state: Edit requirement definition.	f	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
126	0	Record observable evidence that the behavior works: Edit requirement definition.	t	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
127	0	Confirm the implementation matches the documented contract: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
128	0	Add an automated test for the primary success path: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
129	0	Add an automated test for invalid input: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
130	0	Verify database changes are atomic on failure: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
131	0	Verify the user-facing error identifies the corrective action: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
132	0	Review naming and behavior against existing project conventions: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
133	0	Confirm repeated execution does not create duplicate state: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
134	0	Record observable evidence that the behavior works: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
135	0	Complete peer review of the delivered behavior: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
136	0	Confirm the implementation matches the documented contract: Create binary requirement.	f	46	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
137	0	Confirm the implementation matches the documented contract: Summarize phase completeness.	f	47	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
138	0	Add an automated test for the primary success path: Summarize phase completeness.	t	47	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
139	0	Confirm the implementation matches the documented contract: Represent repair work.	t	48	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
140	0	Add an automated test for the primary success path: Represent repair work.	t	48	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
141	0	Add an automated test for invalid input: Represent repair work.	t	48	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
142	0	Confirm the implementation matches the documented contract: Identify production candidates.	f	49	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
143	0	Add an automated test for the primary success path: Identify production candidates.	f	49	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
144	0	Add an automated test for invalid input: Identify production candidates.	f	49	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
145	0	Verify database changes are atomic on failure: Identify production candidates.	f	49	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
146	0	Confirm the implementation matches the documented contract: Identify review backlog.	f	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
147	0	Add an automated test for the primary success path: Identify review backlog.	t	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
148	0	Add an automated test for invalid input: Identify review backlog.	f	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
149	0	Verify database changes are atomic on failure: Identify review backlog.	t	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
150	0	Verify the user-facing error identifies the corrective action: Identify review backlog.	f	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
151	0	Confirm the implementation matches the documented contract: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
152	0	Add an automated test for the primary success path: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
153	0	Add an automated test for invalid input: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
154	0	Verify database changes are atomic on failure: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
155	0	Verify the user-facing error identifies the corrective action: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
156	0	Review naming and behavior against existing project conventions: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
157	0	Confirm the implementation matches the documented contract: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
158	0	Add an automated test for the primary success path: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
159	0	Add an automated test for invalid input: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
160	0	Verify database changes are atomic on failure: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
161	0	Verify the user-facing error identifies the corrective action: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
162	0	Review naming and behavior against existing project conventions: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
163	0	Confirm repeated execution does not create duplicate state: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
300	0	Done changes preserve the version.	t	318	2026-06-23 04:39:15.017353+02	2026-06-23 04:39:15.023228+02
164	0	Confirm the implementation matches the documented contract: Group tasks by workflow phase.	f	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
165	0	Add an automated test for the primary success path: Group tasks by workflow phase.	t	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
166	0	Add an automated test for invalid input: Group tasks by workflow phase.	f	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
167	0	Verify database changes are atomic on failure: Group tasks by workflow phase.	t	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
168	0	Verify the user-facing error identifies the corrective action: Group tasks by workflow phase.	f	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
169	0	Review naming and behavior against existing project conventions: Group tasks by workflow phase.	t	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
170	0	Confirm repeated execution does not create duplicate state: Group tasks by workflow phase.	f	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
171	0	Record observable evidence that the behavior works: Group tasks by workflow phase.	t	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
172	0	Confirm the implementation matches the documented contract: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
173	0	Add an automated test for the primary success path: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
174	0	Add an automated test for invalid input: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
175	0	Verify database changes are atomic on failure: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
176	0	Verify the user-facing error identifies the corrective action: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
177	0	Review naming and behavior against existing project conventions: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
178	0	Confirm repeated execution does not create duplicate state: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
179	0	Record observable evidence that the behavior works: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
180	0	Complete peer review of the delivered behavior: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
181	0	Confirm the implementation matches the documented contract: Return consistent JSON errors.	f	55	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
182	0	Confirm the implementation matches the documented contract: Log structured request context.	f	56	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
183	0	Add an automated test for the primary success path: Log structured request context.	t	56	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
185	0	Add an automated test for the primary success path: Expose health endpoint.	t	57	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
186	0	Add an automated test for invalid input: Expose health endpoint.	t	57	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
187	0	Confirm the implementation matches the documented contract: Test requirement aggregation.	f	58	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
188	0	Add an automated test for the primary success path: Test requirement aggregation.	f	58	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
189	0	Add an automated test for invalid input: Test requirement aggregation.	f	58	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
190	0	Verify database changes are atomic on failure: Test requirement aggregation.	f	58	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
191	0	Confirm the implementation matches the documented contract: Test task concurrency.	f	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
192	0	Add an automated test for the primary success path: Test task concurrency.	t	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
193	0	Add an automated test for invalid input: Test task concurrency.	f	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
194	0	Verify database changes are atomic on failure: Test task concurrency.	t	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
195	0	Verify the user-facing error identifies the corrective action: Test task concurrency.	f	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
196	0	Confirm the implementation matches the documented contract: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
197	0	Add an automated test for the primary success path: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
198	0	Add an automated test for invalid input: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
199	0	Verify database changes are atomic on failure: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
200	0	Verify the user-facing error identifies the corrective action: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
201	0	Review naming and behavior against existing project conventions: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
303	0	Verify counters reach the parent task.	t	329	2026-06-23 04:39:15.119932+02	2026-06-23 04:39:15.125964+02
184	0	Confirm the implementation matches the documented contract: Expose health endpoint.	f	57	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
302	2	Add requirement toggle endpoint test.	f	324	2026-06-23 04:39:15.049335+02	2026-06-23 04:39:15.090455+02
304	0	Counters follow re-parented tasks.	t	330	2026-06-23 04:39:15.122541+02	2026-06-23 04:39:15.129027+02
308	0	Done changes preserve the version.	t	342	2026-06-23 04:40:06.725839+02	2026-06-23 04:40:06.731423+02
311	0	Verify counters reach the parent task.	t	353	2026-06-23 04:40:06.826575+02	2026-06-23 04:40:06.832992+02
312	0	Counters follow re-parented tasks.	t	354	2026-06-23 04:40:06.829419+02	2026-06-23 04:40:06.835619+02
310	2	Add requirement toggle endpoint test.	f	348	2026-06-23 04:40:06.758039+02	2026-06-23 04:40:06.797996+02
292	0	Done changes preserve the version.	t	294	2026-06-23 04:07:00.067161+02	2026-06-23 04:07:00.07294+02
294	2	Add requirement toggle endpoint test.	f	300	2026-06-23 04:07:00.099347+02	2026-06-23 04:07:00.138525+02
387	0	Task tree delete archives this requirement.	f	569	2026-06-24 16:20:05.139461+02	2026-06-24 16:20:05.139461+02
295	0	Verify counters reach the parent task.	t	305	2026-06-23 04:07:00.166315+02	2026-06-23 04:07:00.172429+02
296	0	Counters follow re-parented tasks.	t	306	2026-06-23 04:07:00.169216+02	2026-06-23 04:07:00.174864+02
\.


--
-- Data for Name: requirement_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requirement_history (id, version, definition, modified, deleted) FROM stdin;
202	0	Add requirement create endpoint test.	2026-06-22 17:38:06.23203+02	f
203	0	Add requirement update endpoint test.	2026-06-22 17:38:06.237842+02	f
203	1	Add requirement update endpoint test.	2026-06-22 17:38:06.250511+02	f
203	2	Text-only update preserves completion state.	2026-06-22 17:38:06.254738+02	f
202	1	Add requirement create endpoint test.	2026-06-22 17:38:06.243289+02	t
203	3	Add requirement toggle endpoint test.	2026-06-22 17:38:06.260858+02	t
204	0	Verify counters reach the parent task.	2026-06-22 17:38:06.296269+02	f
204	1	Verify counters reach the parent task.	2026-06-22 17:38:06.30262+02	t
207	0	Project delete archives this requirement.	2026-06-23 00:01:10.850199+02	t
206	1	Add requirement update endpoint test.	2026-06-23 00:01:10.854219+02	f
206	2	Text-only update preserves completion state.	2026-06-23 00:01:10.858749+02	f
205	1	Add requirement create endpoint test.	2026-06-23 00:01:10.847295+02	t
206	3	Add requirement toggle endpoint test.	2026-06-23 00:01:10.865026+02	t
208	0	Task tree delete archives this requirement.	2026-06-23 00:01:10.892076+02	t
209	1	Verify counters reach the parent task.	2026-06-23 00:01:10.906661+02	t
210	0	Project delete archives this requirement.	2026-06-23 00:01:41.627258+02	t
212	1	Add requirement update endpoint test.	2026-06-23 00:01:41.685588+02	f
212	2	Text-only update preserves completion state.	2026-06-23 00:01:41.690691+02	f
211	1	Add requirement create endpoint test.	2026-06-23 00:01:41.678814+02	t
212	3	Add requirement toggle endpoint test.	2026-06-23 00:01:41.696404+02	t
213	0	Task tree delete archives this requirement.	2026-06-23 00:01:41.729741+02	t
214	1	Verify counters reach the parent task.	2026-06-23 00:01:41.739183+02	t
215	0	Delete the final requirement transactionally.	2026-06-23 00:03:37.182515+02	t
216	0	Project delete archives this requirement.	2026-06-23 00:03:37.200933+02	t
217	0	Require an expected version.	2026-06-23 00:03:37.212696+02	t
219	1	Add requirement update endpoint test.	2026-06-23 00:03:37.256402+02	f
219	2	Text-only update preserves completion state.	2026-06-23 00:03:37.26305+02	f
218	1	Add requirement create endpoint test.	2026-06-23 00:03:37.249259+02	t
219	3	Add requirement toggle endpoint test.	2026-06-23 00:03:37.270632+02	t
220	1	Verify counters reach the parent task.	2026-06-23 00:03:37.319856+02	t
221	0	Task tree delete archives this requirement.	2026-06-23 00:03:37.359669+02	t
222	0	Delete the final requirement transactionally.	2026-06-23 00:05:54.088131+02	t
223	0	Project delete archives this requirement.	2026-06-23 00:05:54.116166+02	t
224	0	Require an expected version.	2026-06-23 00:05:54.149329+02	t
226	1	Add requirement update endpoint test.	2026-06-23 00:05:54.228489+02	f
226	2	Text-only update preserves completion state.	2026-06-23 00:05:54.238676+02	f
225	1	Add requirement create endpoint test.	2026-06-23 00:05:54.216919+02	t
226	3	Add requirement toggle endpoint test.	2026-06-23 00:05:54.250534+02	t
227	1	Verify counters reach the parent task.	2026-06-23 00:05:54.329418+02	t
228	0	Task tree delete archives this requirement.	2026-06-23 00:05:54.381992+02	t
229	0	Delete the final requirement transactionally.	2026-06-23 00:11:52.827519+02	t
230	0	Project delete archives this requirement.	2026-06-23 00:11:52.846914+02	t
231	0	Require an expected version.	2026-06-23 00:11:52.858366+02	t
233	1	Add requirement update endpoint test.	2026-06-23 00:11:52.901106+02	f
233	2	Text-only update preserves completion state.	2026-06-23 00:11:52.906118+02	f
232	1	Add requirement create endpoint test.	2026-06-23 00:11:52.894315+02	t
233	3	Add requirement toggle endpoint test.	2026-06-23 00:11:52.911623+02	t
234	1	Verify counters reach the parent task.	2026-06-23 00:11:52.954197+02	t
235	0	Task tree delete archives this requirement.	2026-06-23 00:11:52.989022+02	t
236	0	Delete the final requirement transactionally.	2026-06-23 00:21:16.527549+02	t
237	0	Project delete archives this requirement.	2026-06-23 00:21:16.54202+02	t
238	0	Require an expected version.	2026-06-23 00:21:16.555909+02	t
240	1	Add requirement update endpoint test.	2026-06-23 00:21:16.598436+02	f
240	2	Text-only update preserves completion state.	2026-06-23 00:21:16.602762+02	f
239	1	Add requirement create endpoint test.	2026-06-23 00:21:16.591407+02	t
240	3	Add requirement toggle endpoint test.	2026-06-23 00:21:16.608682+02	t
241	1	Verify counters reach the parent task.	2026-06-23 00:21:16.650317+02	t
242	0	Task tree delete archives this requirement.	2026-06-23 00:21:16.688527+02	t
243	0	Delete the final requirement transactionally.	2026-06-23 01:38:17.015833+02	t
244	0	Project delete archives this requirement.	2026-06-23 01:38:17.043121+02	t
245	0	Done changes preserve the version.	2026-06-23 01:38:17.057346+02	t
247	0	Add requirement update endpoint test.	2026-06-23 01:38:17.098773+02	f
247	1	Text-only update preserves completion state.	2026-06-23 01:38:17.104076+02	f
246	0	Add requirement create endpoint test.	2026-06-23 01:38:17.092858+02	t
247	2	Add requirement toggle endpoint test.	2026-06-23 01:38:17.115549+02	t
248	0	Verify counters reach the parent task.	2026-06-23 01:38:17.156216+02	t
249	0	Task tree delete archives this requirement.	2026-06-23 01:38:17.210522+02	t
250	0	Project delete archives this requirement.	2026-06-23 01:39:30.00987+02	t
251	0	Delete the final requirement transactionally.	2026-06-23 01:39:30.034887+02	t
252	0	Done changes preserve the version.	2026-06-23 01:39:30.069995+02	t
254	0	Add requirement update endpoint test.	2026-06-23 01:39:30.11209+02	f
254	1	Text-only update preserves completion state.	2026-06-23 01:39:30.117731+02	f
253	0	Add requirement create endpoint test.	2026-06-23 01:39:30.106284+02	t
254	2	Add requirement toggle endpoint test.	2026-06-23 01:39:30.14164+02	t
255	0	Verify counters reach the parent task.	2026-06-23 01:39:30.183232+02	t
256	0	Task tree delete archives this requirement.	2026-06-23 01:39:30.223246+02	t
257	0	Delete the final requirement transactionally.	2026-06-23 01:56:43.638514+02	t
258	0	Project delete archives this requirement.	2026-06-23 01:56:43.655793+02	t
259	0	Done changes preserve the version.	2026-06-23 01:56:43.672551+02	t
261	0	Add requirement update endpoint test.	2026-06-23 01:56:43.713955+02	f
261	1	Text-only update preserves completion state.	2026-06-23 01:56:43.719272+02	f
260	0	Add requirement create endpoint test.	2026-06-23 01:56:43.708157+02	t
261	2	Add requirement toggle endpoint test.	2026-06-23 01:56:43.742314+02	t
262	0	Verify counters reach the parent task.	2026-06-23 01:56:43.782777+02	t
263	0	Task tree delete archives this requirement.	2026-06-23 01:56:43.817227+02	t
266	0	Delete the final requirement transactionally.	2026-06-23 02:29:41.080406+02	t
267	0	Project delete archives this requirement.	2026-06-23 02:29:41.100608+02	t
268	0	Done changes preserve the version.	2026-06-23 02:29:41.114155+02	t
270	0	Add requirement update endpoint test.	2026-06-23 02:29:41.149471+02	f
270	1	Text-only update preserves completion state.	2026-06-23 02:29:41.154237+02	f
269	0	Add requirement create endpoint test.	2026-06-23 02:29:41.143165+02	t
270	2	Add requirement toggle endpoint test.	2026-06-23 02:29:41.176946+02	t
271	0	Verify counters reach the parent task.	2026-06-23 02:29:41.217035+02	t
272	0	Counters follow re-parented tasks.	2026-06-23 02:29:41.276288+02	t
273	0	Task tree delete archives this requirement.	2026-06-23 02:29:41.350719+02	t
274	0	Delete the final requirement transactionally.	2026-06-23 02:33:46.290895+02	t
275	0	Project delete archives this requirement.	2026-06-23 02:33:46.314526+02	t
276	0	Done changes preserve the version.	2026-06-23 02:33:46.336284+02	t
278	0	Add requirement update endpoint test.	2026-06-23 02:33:46.377903+02	f
278	1	Text-only update preserves completion state.	2026-06-23 02:33:46.382733+02	f
277	0	Add requirement create endpoint test.	2026-06-23 02:33:46.371474+02	t
278	2	Add requirement toggle endpoint test.	2026-06-23 02:33:46.404884+02	t
279	0	Verify counters reach the parent task.	2026-06-23 02:33:46.444089+02	t
280	0	Counters follow re-parented tasks.	2026-06-23 02:33:46.452304+02	t
281	0	Task tree delete archives this requirement.	2026-06-23 02:33:46.529432+02	t
282	0	Delete the final requirement transactionally.	2026-06-23 02:41:30.191075+02	t
283	0	Project delete archives this requirement.	2026-06-23 02:41:30.20923+02	t
284	0	Done changes preserve the version.	2026-06-23 02:41:30.226009+02	t
286	0	Add requirement update endpoint test.	2026-06-23 02:41:30.267759+02	f
286	1	Text-only update preserves completion state.	2026-06-23 02:41:30.272648+02	f
285	0	Add requirement create endpoint test.	2026-06-23 02:41:30.261393+02	t
286	2	Add requirement toggle endpoint test.	2026-06-23 02:41:30.296949+02	t
287	0	Verify counters reach the parent task.	2026-06-23 02:41:30.338642+02	t
288	0	Counters follow re-parented tasks.	2026-06-23 02:41:30.347318+02	t
289	0	Task tree delete archives this requirement.	2026-06-23 02:41:30.426158+02	t
290	0	Delete the final requirement transactionally.	2026-06-23 04:07:00.043662+02	t
291	0	Project delete archives this requirement.	2026-06-23 04:07:00.061203+02	t
294	0	Add requirement update endpoint test.	2026-06-23 04:07:00.111061+02	f
294	1	Text-only update preserves completion state.	2026-06-23 04:07:00.116358+02	f
293	0	Add requirement create endpoint test.	2026-06-23 04:07:00.105533+02	t
297	0	Task tree delete archives this requirement.	2026-06-23 04:07:00.244164+02	t
298	0	Delete the final requirement transactionally.	2026-06-23 04:39:14.994223+02	t
299	0	Project delete archives this requirement.	2026-06-23 04:39:15.01211+02	t
302	0	Add requirement update endpoint test.	2026-06-23 04:39:15.061426+02	f
302	1	Text-only update preserves completion state.	2026-06-23 04:39:15.067122+02	f
301	0	Add requirement create endpoint test.	2026-06-23 04:39:15.055847+02	t
305	0	Task tree delete archives this requirement.	2026-06-23 04:39:15.200351+02	t
306	0	Delete the final requirement transactionally.	2026-06-23 04:40:06.703005+02	t
307	0	Project delete archives this requirement.	2026-06-23 04:40:06.720131+02	t
310	0	Add requirement update endpoint test.	2026-06-23 04:40:06.769944+02	f
310	1	Text-only update preserves completion state.	2026-06-23 04:40:06.775058+02	f
309	0	Add requirement create endpoint test.	2026-06-23 04:40:06.763917+02	t
313	0	Task tree delete archives this requirement.	2026-06-23 04:40:06.907978+02	t
314	0	Delete the final requirement transactionally.	2026-06-23 04:46:01.067242+02	t
315	0	Project delete archives this requirement.	2026-06-23 04:46:01.086038+02	t
316	0	Done changes preserve the version.	2026-06-23 04:46:01.109121+02	t
318	0	Add requirement update endpoint test.	2026-06-23 04:46:01.155+02	f
318	1	Text-only update preserves completion state.	2026-06-23 04:46:01.159435+02	f
317	0	Add requirement create endpoint test.	2026-06-23 04:46:01.148534+02	t
318	2	Add requirement toggle endpoint test.	2026-06-23 04:46:01.182755+02	t
319	0	Verify counters reach the parent task.	2026-06-23 04:46:01.241778+02	t
320	0	Counters follow re-parented tasks.	2026-06-23 04:46:01.266275+02	t
321	0	Task tree delete archives this requirement.	2026-06-23 04:46:01.364272+02	t
322	0	Delete the final requirement transactionally.	2026-06-23 05:02:49.495187+02	t
323	0	Project delete archives this requirement.	2026-06-23 05:02:49.518287+02	t
324	0	Done changes preserve the version.	2026-06-23 05:02:49.535394+02	t
326	0	Add requirement update endpoint test.	2026-06-23 05:02:49.582279+02	f
326	1	Text-only update preserves completion state.	2026-06-23 05:02:49.587782+02	f
325	0	Add requirement create endpoint test.	2026-06-23 05:02:49.576735+02	t
326	2	Add requirement toggle endpoint test.	2026-06-23 05:02:49.61057+02	t
327	0	Verify counters reach the parent task.	2026-06-23 05:02:49.66196+02	t
328	0	Counters follow re-parented tasks.	2026-06-23 05:02:49.676567+02	t
329	0	Task tree delete archives this requirement.	2026-06-23 05:02:49.774685+02	t
330	0	Delete the final requirement transactionally.	2026-06-23 05:03:28.538298+02	t
331	0	Project delete archives this requirement.	2026-06-23 05:03:28.566151+02	t
332	0	Done changes preserve the version.	2026-06-23 05:03:28.588131+02	t
334	0	Add requirement update endpoint test.	2026-06-23 05:03:28.641896+02	f
334	1	Text-only update preserves completion state.	2026-06-23 05:03:28.64604+02	f
333	0	Add requirement create endpoint test.	2026-06-23 05:03:28.635042+02	t
334	2	Add requirement toggle endpoint test.	2026-06-23 05:03:28.66943+02	t
335	0	Verify counters reach the parent task.	2026-06-23 05:03:28.722036+02	t
336	0	Counters follow re-parented tasks.	2026-06-23 05:03:28.73629+02	t
337	0	Task tree delete archives this requirement.	2026-06-23 05:03:28.831733+02	t
338	0	Delete the final requirement transactionally.	2026-06-23 12:23:19.535723+02	t
339	0	Project delete archives this requirement.	2026-06-23 12:23:19.55416+02	t
340	0	Done changes preserve the version.	2026-06-23 12:23:19.577676+02	t
342	0	Add requirement update endpoint test.	2026-06-23 12:23:19.626735+02	f
342	1	Text-only update preserves completion state.	2026-06-23 12:23:19.631744+02	f
341	0	Add requirement create endpoint test.	2026-06-23 12:23:19.620225+02	t
342	2	Add requirement toggle endpoint test.	2026-06-23 12:23:19.655586+02	t
343	0	Verify counters reach the parent task.	2026-06-23 12:23:19.707568+02	t
344	0	Counters follow re-parented tasks.	2026-06-23 12:23:19.721704+02	t
345	0	Task tree delete archives this requirement.	2026-06-23 12:23:19.808831+02	t
346	0	Delete the final requirement transactionally.	2026-06-23 12:26:37.987255+02	t
347	0	Project delete archives this requirement.	2026-06-23 12:26:38.006174+02	t
348	0	Done changes preserve the version.	2026-06-23 12:26:38.029232+02	t
350	0	Add requirement update endpoint test.	2026-06-23 12:26:38.076703+02	f
350	1	Text-only update preserves completion state.	2026-06-23 12:26:38.082017+02	f
349	0	Add requirement create endpoint test.	2026-06-23 12:26:38.070372+02	t
350	2	Add requirement toggle endpoint test.	2026-06-23 12:26:38.106459+02	t
351	0	Verify counters reach the parent task.	2026-06-23 12:26:38.161793+02	t
352	0	Counters follow re-parented tasks.	2026-06-23 12:26:38.177239+02	t
353	0	Task tree delete archives this requirement.	2026-06-23 12:26:38.272087+02	t
354	0	Delete the final requirement transactionally.	2026-06-23 12:40:54.439367+02	t
355	0	Project delete archives this requirement.	2026-06-23 12:40:54.457824+02	t
356	0	Done changes preserve the version.	2026-06-23 12:40:54.480406+02	t
358	0	Add requirement update endpoint test.	2026-06-23 12:40:54.526867+02	f
358	1	Text-only update preserves completion state.	2026-06-23 12:40:54.531682+02	f
357	0	Add requirement create endpoint test.	2026-06-23 12:40:54.520495+02	t
358	2	Add requirement toggle endpoint test.	2026-06-23 12:40:54.554355+02	t
359	0	Verify counters reach the parent task.	2026-06-23 12:40:54.605961+02	t
360	0	Counters follow re-parented tasks.	2026-06-23 12:40:54.625909+02	t
361	0	Task tree delete archives this requirement.	2026-06-23 12:40:54.719322+02	t
362	0	Delete the final requirement transactionally.	2026-06-23 12:42:22.105303+02	t
363	0	Project delete archives this requirement.	2026-06-23 12:42:22.129277+02	t
364	0	Done changes preserve the version.	2026-06-23 12:42:22.146882+02	t
366	0	Add requirement update endpoint test.	2026-06-23 12:42:22.195243+02	f
366	1	Text-only update preserves completion state.	2026-06-23 12:42:22.20022+02	f
365	0	Add requirement create endpoint test.	2026-06-23 12:42:22.188776+02	t
366	2	Add requirement toggle endpoint test.	2026-06-23 12:42:22.223897+02	t
367	0	Verify counters reach the parent task.	2026-06-23 12:42:22.277056+02	t
368	0	Counters follow re-parented tasks.	2026-06-23 12:42:22.291679+02	t
369	0	Task tree delete archives this requirement.	2026-06-23 12:42:22.382214+02	t
371	0	Delete the final requirement transactionally.	2026-06-24 16:02:25.29977+02	t
372	0	Project delete archives this requirement.	2026-06-24 16:02:25.311448+02	t
373	0	Done changes preserve the version.	2026-06-24 16:02:25.345134+02	t
375	0	Add requirement update endpoint test.	2026-06-24 16:02:25.391611+02	f
375	1	Text-only update preserves completion state.	2026-06-24 16:02:25.396847+02	f
374	0	Add requirement create endpoint test.	2026-06-24 16:02:25.385334+02	t
375	2	Add requirement toggle endpoint test.	2026-06-24 16:02:25.419973+02	t
376	0	Verify counters reach the parent task.	2026-06-24 16:02:25.47309+02	t
377	0	Counters follow re-parented tasks.	2026-06-24 16:02:25.486604+02	t
370	0	Task tree delete archives this requirement.	2026-06-24 16:02:14.143206+02	t
378	0	Task tree delete archives this requirement.	2026-06-24 16:02:25.578951+02	t
379	0	Delete the final requirement transactionally.	2026-06-24 16:03:18.77293+02	t
380	0	Project delete archives this requirement.	2026-06-24 16:03:18.781372+02	t
381	0	Done changes preserve the version.	2026-06-24 16:03:18.81167+02	t
383	0	Add requirement update endpoint test.	2026-06-24 16:03:18.859438+02	f
383	1	Text-only update preserves completion state.	2026-06-24 16:03:18.863926+02	f
382	0	Add requirement create endpoint test.	2026-06-24 16:03:18.85272+02	t
383	2	Add requirement toggle endpoint test.	2026-06-24 16:03:18.886522+02	t
384	0	Verify counters reach the parent task.	2026-06-24 16:03:18.939067+02	t
385	0	Counters follow re-parented tasks.	2026-06-24 16:03:18.952843+02	t
386	0	Task tree delete archives this requirement.	2026-06-24 16:03:19.062008+02	t
388	0	Delete the final requirement transactionally.	2026-06-24 16:20:31.071612+02	t
389	0	Project delete archives this requirement.	2026-06-24 16:20:31.09211+02	t
390	0	Done changes preserve the version.	2026-06-24 16:20:31.115262+02	t
392	0	Add requirement update endpoint test.	2026-06-24 16:20:31.162853+02	f
392	1	Text-only update preserves completion state.	2026-06-24 16:20:31.168668+02	f
391	0	Add requirement create endpoint test.	2026-06-24 16:20:31.157317+02	t
392	2	Add requirement toggle endpoint test.	2026-06-24 16:20:31.192142+02	t
393	0	Verify counters reach the parent task.	2026-06-24 16:20:31.244491+02	t
394	0	Counters follow re-parented tasks.	2026-06-24 16:20:31.25893+02	t
395	0	Task tree delete archives this requirement.	2026-06-24 16:20:31.34953+02	t
\.


--
-- Name: change_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.change_id_seq', 1, false);


--
-- Name: epic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.epic_id_seq', 1, false);


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.project_id_seq', 348, true);


--
-- Name: requirement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.requirement_id_seq', 395, true);


--
-- Name: epic_history epic_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.epic_history
    ADD CONSTRAINT epic_history_pkey PRIMARY KEY (id, version);


--
-- Name: epic epic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.epic
    ADD CONSTRAINT epic_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: requirement_history requirement_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requirement_history
    ADD CONSTRAINT requirement_history_pkey PRIMARY KEY (id, version);


--
-- Name: requirement requirement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requirement
    ADD CONSTRAINT requirement_pkey PRIMARY KEY (id);


--
-- Name: change_history task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_history
    ADD CONSTRAINT task_history_pkey PRIMARY KEY (id, version);


--
-- Name: change_phase task_phase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_phase
    ADD CONSTRAINT task_phase_pkey PRIMARY KEY (slug);


--
-- Name: change task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: change_type task_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_type
    ADD CONSTRAINT task_type_pkey PRIMARY KEY (slug);


--
-- PostgreSQL database dump complete
--

\unrestrict hNrQYYnCxgtpkjlNVkZm3lpf4pKR2HehpQR3MEaQg87CXengO7i0krD86n4o0BM

