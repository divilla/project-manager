--
-- PostgreSQL database dump
--

\restrict 4dTX2Sq2fpKriwsWNTTmQ1tNAbFEbCWvBqaJfc7vbkcsEvvBpb3BGTN9JNRSrN3

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.task_type DROP CONSTRAINT task_type_pkey;
ALTER TABLE ONLY public.task DROP CONSTRAINT task_pkey;
ALTER TABLE ONLY public.task_phase DROP CONSTRAINT task_phase_pkey;
ALTER TABLE ONLY public.task_history DROP CONSTRAINT task_history_pkey;
ALTER TABLE ONLY public.requirement DROP CONSTRAINT requirement_pkey;
ALTER TABLE ONLY public.requirement_history DROP CONSTRAINT requirement_history_pkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_pkey;
DROP VIEW public.vw_task;
DROP VIEW public.vw_project;
DROP TABLE public.task_type;
DROP TABLE public.task_phase;
DROP TABLE public.task_history;
DROP TABLE public.task;
DROP TABLE public.requirement_history;
DROP TABLE public.requirement;
DROP TABLE public.project;
DROP PROCEDURE public.sp_task_to_history(IN _id bigint, IN _deleted boolean);
DROP PROCEDURE public.sp_task_requirement_recalculate(IN _task_id bigint);
DROP PROCEDURE public.sp_task_phase_recalculate(IN _parent_id bigint);
DROP PROCEDURE public.sp_requirement_to_history(IN _id bigint, IN _deleted boolean);
DROP FUNCTION public.fn_task_descendants(_task_id bigint, _descendants bigint[]);
--
-- Name: fn_task_descendants(bigint, bigint[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_task_descendants(_task_id bigint, _descendants bigint[]) RETURNS bigint[]
    LANGUAGE plpgsql
    AS $$
declare
    _row public.task%rowtype;
begin
    for _row in select * from task where parent_id=_task_id loop
        _descendants = _descendants || _row.id;
        _descendants = fn_task_descendants(_row.id, _descendants);
    end loop;

    return _descendants;
end;
$$;


ALTER FUNCTION public.fn_task_descendants(_task_id bigint, _descendants bigint[]) OWNER TO postgres;

--
-- Name: sp_requirement_to_history(bigint, boolean); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_requirement_to_history(IN _id bigint, IN _deleted boolean)
    LANGUAGE plpgsql
    AS $$
begin
    insert into public.requirement_history (
        id, version, definition, modified, deleted
    )
    select
        id, version, definition, modified, _deleted
    from public.requirement
    where id = _id;
end;
$$;


ALTER PROCEDURE public.sp_requirement_to_history(IN _id bigint, IN _deleted boolean) OWNER TO postgres;

--
-- Name: sp_task_phase_recalculate(bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_task_phase_recalculate(IN _parent_id bigint)
    LANGUAGE plpgsql
    AS $$
declare
    _priority smallint;
    _slug text;
begin
    loop
        select min(tp.priority) into _priority from task t join task_phase tp on t.task_phase=tp.slug where parent_id=_parent_id;

        if _priority is not null then
            select slug into _slug from task_phase where priority=_priority;

            update public.task
            set
                task_phase=_slug
            where id=_parent_id;
        end if;

        select parent_id into _parent_id from task where id=_parent_id;
        if _parent_id is null then
            exit;
        end if;
    end loop;
end;
$$;


ALTER PROCEDURE public.sp_task_phase_recalculate(IN _parent_id bigint) OWNER TO postgres;

--
-- Name: sp_task_requirement_recalculate(bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_task_requirement_recalculate(IN _task_id bigint)
    LANGUAGE plpgsql
    AS $$
declare
    _done_req smallint;
    _total_req smallint;
    _done_task smallint;
    _total_task smallint;
begin
    loop
        select count(*) into _done_req from requirement where task_id=_task_id and done=true;
        select count(*) into _total_req from requirement where task_id=_task_id;

        select
            coalesce(sum(done_req), 0),
            coalesce(sum(total_req), 0)
        into
            _done_task,
            _total_task
        from public.task
        where parent_id=_task_id;

        update public.task
        set
            done_req=_done_req+_done_task,
            total_req=_total_req+_total_task
        where id=_task_id;

        select parent_id into _task_id from task where id=_task_id;
        if _task_id is null then
            exit;
        end if;
    end loop;
end;
$$;


ALTER PROCEDURE public.sp_task_requirement_recalculate(IN _task_id bigint) OWNER TO postgres;

--
-- Name: sp_task_to_history(bigint, boolean); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_task_to_history(IN _id bigint, IN _deleted boolean)
    LANGUAGE plpgsql
    AS $$
begin
    insert into public.task_history (
        id, version, task_type, name, description, parent_id, modified, deleted
    )
    select
        id, version, task_type, name, description, parent_id, modified, _deleted
    from public.task
    where id = _id;
end;
$$;


ALTER PROCEDURE public.sp_task_to_history(IN _id bigint, IN _deleted boolean) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint NOT NULL,
    name text NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.project ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: requirement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requirement (
    id bigint NOT NULL,
    version smallint DEFAULT 0 NOT NULL,
    definition text NOT NULL,
    done boolean DEFAULT false NOT NULL,
    task_id bigint NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.requirement OWNER TO postgres;

--
-- Name: requirement_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requirement_history (
    id bigint NOT NULL,
    version smallint NOT NULL,
    definition text NOT NULL,
    modified timestamp with time zone NOT NULL,
    deleted boolean NOT NULL
);


ALTER TABLE public.requirement_history OWNER TO postgres;

--
-- Name: requirement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.requirement ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.requirement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id bigint NOT NULL,
    version smallint DEFAULT 0 NOT NULL,
    task_type text DEFAULT 'task'::text NOT NULL,
    name text NOT NULL,
    description text,
    difficulty smallint DEFAULT 1 NOT NULL,
    priority smallint DEFAULT 0 NOT NULL,
    task_phase text DEFAULT 'backlog'::text NOT NULL,
    parent_id bigint,
    project_id bigint NOT NULL,
    done_req smallint DEFAULT 0 NOT NULL,
    total_req smallint DEFAULT 0 NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task OWNER TO postgres;

--
-- Name: task_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_history (
    id bigint NOT NULL,
    version smallint NOT NULL,
    task_type text NOT NULL,
    name text NOT NULL,
    description text,
    parent_id bigint,
    modified timestamp with time zone NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.task_history OWNER TO postgres;

--
-- Name: task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.task ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: task_phase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_phase (
    slug text DEFAULT 'backlog'::text NOT NULL,
    priority integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.task_phase OWNER TO postgres;

--
-- Name: task_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_type (
    slug text DEFAULT 'task'::text NOT NULL,
    priority integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.task_type OWNER TO postgres;

--
-- Name: vw_project; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_project AS
 SELECT p.id,
    p.name,
    p.created,
    p.modified,
    count(t.*) AS task_count
   FROM (public.project p
     LEFT JOIN public.task t ON ((p.id = t.project_id)))
  GROUP BY p.id, p.name, p.created, p.modified
  ORDER BY p.id;


ALTER VIEW public.vw_project OWNER TO postgres;

--
-- Name: vw_task; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_task AS
 SELECT id,
    version,
    task_type,
    name,
    description,
    difficulty,
    priority,
    task_phase,
    parent_id,
    project_id,
    done_req,
    total_req,
    created,
    modified,
        CASE
            WHEN (total_req = 0) THEN (0)::smallint
            ELSE (((100 * done_req) / total_req))::smallint
        END AS completed
   FROM public.task;


ALTER VIEW public.vw_task OWNER TO postgres;

--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, name, created, modified) FROM stdin;
1	demo1	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
2	demo2	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
3	demo3	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
182	api-test-requirement-project-1782182354984020897	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
183	api-test-task-project-1782182354986938126	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
185	api-test-requirement-project-1782182355006283637	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
186	api-test-requirement-project-1782182355032823498	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
187	api-test-task-project-1782182355042085825	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
188	api-test-task-project-1782182355076596029	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
189	api-test-task-project-1782182355100040653	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
190	api-test-requirement-project-1782182355102808509	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
191	api-test-task-project-1782182355140486267	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
196	api-test-requirement-project-1782182406693553251	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
197	api-test-task-project-1782182406695628902	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
199	api-test-requirement-project-1782182406714962641	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
200	api-test-requirement-project-1782182406741413202	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
201	api-test-task-project-1782182406749915135	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
202	api-test-task-project-1782182406784096134	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
203	api-test-task-project-1782182406806958062	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
204	api-test-requirement-project-1782182406810219855	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
205	api-test-task-project-1782182406846983178	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
168	api-test-requirement-project-1782180420029023955	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
169	api-test-task-project-1782180420032179366	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
171	api-test-requirement-project-1782180420056001486	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
172	api-test-requirement-project-1782180420081917871	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
173	api-test-task-project-1782180420091331564	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
174	api-test-task-project-1782180420125185329	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
175	api-test-task-project-1782180420147606368	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
176	api-test-requirement-project-1782180420150651589	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
177	api-test-task-project-1782180420185754226	2026-06-23 04:51:21.08383+02	2026-06-23 04:51:21.091494+02
\.


--
-- Data for Name: requirement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requirement (id, version, definition, done, task_id, created, modified) FROM stdin;
1	0	Confirm the implementation matches the documented contract: Document incremental migration ordering.	f	19	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
2	0	Confirm the implementation matches the documented contract: Seed realistic demonstration data.	f	20	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
3	0	Add an automated test for the primary success path: Seed realistic demonstration data.	t	20	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
4	0	Confirm the implementation matches the documented contract: Seed workflow reference values.	t	21	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
5	0	Add an automated test for the primary success path: Seed workflow reference values.	t	21	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
6	0	Add an automated test for invalid input: Seed workflow reference values.	t	21	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
7	0	Confirm the implementation matches the documented contract: Define clean database bootstrap.	f	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
8	0	Add an automated test for the primary success path: Define clean database bootstrap.	f	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
9	0	Add an automated test for invalid input: Define clean database bootstrap.	f	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
10	0	Verify database changes are atomic on failure: Define clean database bootstrap.	f	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
11	0	Confirm the implementation matches the documented contract: Enable local CORS policy.	f	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
12	0	Add an automated test for the primary success path: Enable local CORS policy.	t	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
13	0	Add an automated test for invalid input: Enable local CORS policy.	f	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
14	0	Verify database changes are atomic on failure: Enable local CORS policy.	t	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
15	0	Verify the user-facing error identifies the corrective action: Enable local CORS policy.	f	23	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
16	0	Confirm the implementation matches the documented contract: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
17	0	Add an automated test for the primary success path: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
18	0	Add an automated test for invalid input: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
19	0	Verify database changes are atomic on failure: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
20	0	Verify the user-facing error identifies the corrective action: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
21	0	Review naming and behavior against existing project conventions: Configure frontend development server.	t	24	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
22	0	Confirm the implementation matches the documented contract: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
23	0	Add an automated test for the primary success path: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
24	0	Add an automated test for invalid input: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
25	0	Verify database changes are atomic on failure: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
26	0	Verify the user-facing error identifies the corrective action: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
27	0	Review naming and behavior against existing project conventions: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
28	0	Confirm repeated execution does not create duplicate state: Configure local API startup.	f	25	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
29	0	Confirm the implementation matches the documented contract: Refresh workspace data.	f	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
30	0	Add an automated test for the primary success path: Refresh workspace data.	t	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
31	0	Add an automated test for invalid input: Refresh workspace data.	f	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
32	0	Verify database changes are atomic on failure: Refresh workspace data.	t	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
33	0	Verify the user-facing error identifies the corrective action: Refresh workspace data.	f	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
34	0	Review naming and behavior against existing project conventions: Refresh workspace data.	t	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
35	0	Confirm repeated execution does not create duplicate state: Refresh workspace data.	f	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
36	0	Record observable evidence that the behavior works: Refresh workspace data.	t	26	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
37	0	Confirm the implementation matches the documented contract: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
38	0	Add an automated test for the primary success path: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
39	0	Add an automated test for invalid input: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
40	0	Verify database changes are atomic on failure: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
41	0	Verify the user-facing error identifies the corrective action: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
42	0	Review naming and behavior against existing project conventions: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
43	0	Confirm repeated execution does not create duplicate state: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
44	0	Record observable evidence that the behavior works: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
45	0	Complete peer review of the delivered behavior: Preserve navigation errors.	t	27	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
46	0	Confirm the implementation matches the documented contract: Render empty workspace state.	f	28	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
47	0	Confirm the implementation matches the documented contract: Select active project.	f	29	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
48	0	Add an automated test for the primary success path: Select active project.	t	29	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
49	0	Confirm the implementation matches the documented contract: Rename existing project.	t	30	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
50	0	Add an automated test for the primary success path: Rename existing project.	t	30	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
51	0	Add an automated test for invalid input: Rename existing project.	t	30	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
52	0	Confirm the implementation matches the documented contract: List project workspaces.	f	31	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
53	0	Add an automated test for the primary success path: List project workspaces.	f	31	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
54	0	Add an automated test for invalid input: List project workspaces.	f	31	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
55	0	Verify database changes are atomic on failure: List project workspaces.	f	31	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
56	0	Confirm the implementation matches the documented contract: Create project endpoint.	f	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
57	0	Add an automated test for the primary success path: Create project endpoint.	t	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
58	0	Add an automated test for invalid input: Create project endpoint.	f	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
59	0	Verify database changes are atomic on failure: Create project endpoint.	t	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
60	0	Verify the user-facing error identifies the corrective action: Create project endpoint.	f	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
61	0	Confirm the implementation matches the documented contract: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
62	0	Add an automated test for the primary success path: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
63	0	Add an automated test for invalid input: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
64	0	Verify database changes are atomic on failure: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
65	0	Verify the user-facing error identifies the corrective action: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
66	0	Review naming and behavior against existing project conventions: Order task board consistently.	t	33	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
67	0	Confirm the implementation matches the documented contract: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
68	0	Add an automated test for the primary success path: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
69	0	Add an automated test for invalid input: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
70	0	Verify database changes are atomic on failure: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
71	0	Verify the user-facing error identifies the corrective action: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
72	0	Review naming and behavior against existing project conventions: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
73	0	Confirm repeated execution does not create duplicate state: Load phase and type options.	f	34	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
74	0	Confirm the implementation matches the documented contract: Reject stale task update.	f	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
75	0	Add an automated test for the primary success path: Reject stale task update.	t	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
76	0	Add an automated test for invalid input: Reject stale task update.	f	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
77	0	Verify database changes are atomic on failure: Reject stale task update.	t	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
78	0	Verify the user-facing error identifies the corrective action: Reject stale task update.	f	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
79	0	Review naming and behavior against existing project conventions: Reject stale task update.	t	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
80	0	Confirm repeated execution does not create duplicate state: Reject stale task update.	f	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
81	0	Record observable evidence that the behavior works: Reject stale task update.	t	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
82	0	Confirm the implementation matches the documented contract: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
83	0	Add an automated test for the primary success path: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
84	0	Add an automated test for invalid input: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
85	0	Verify database changes are atomic on failure: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
86	0	Verify the user-facing error identifies the corrective action: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
87	0	Review naming and behavior against existing project conventions: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
88	0	Confirm repeated execution does not create duplicate state: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
89	0	Record observable evidence that the behavior works: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
90	0	Complete peer review of the delivered behavior: Edit task metadata.	t	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
91	0	Confirm the implementation matches the documented contract: Delete task subtree.	f	37	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
92	0	Confirm the implementation matches the documented contract: Create child task.	f	38	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
93	0	Add an automated test for the primary success path: Create child task.	t	38	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
94	0	Confirm the implementation matches the documented contract: Create root task.	t	39	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
95	0	Add an automated test for the primary success path: Create root task.	t	39	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
96	0	Add an automated test for invalid input: Create root task.	t	39	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
97	0	Confirm the implementation matches the documented contract: Verify multi-level aggregation.	f	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
98	0	Add an automated test for the primary success path: Verify multi-level aggregation.	f	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
99	0	Add an automated test for invalid input: Verify multi-level aggregation.	f	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
100	0	Verify database changes are atomic on failure: Verify multi-level aggregation.	f	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
101	0	Confirm the implementation matches the documented contract: Render derived completion percentage.	f	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
102	0	Add an automated test for the primary success path: Render derived completion percentage.	t	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
103	0	Add an automated test for invalid input: Render derived completion percentage.	f	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
104	0	Verify database changes are atomic on failure: Render derived completion percentage.	t	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
105	0	Verify the user-facing error identifies the corrective action: Render derived completion percentage.	f	41	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
106	0	Confirm the implementation matches the documented contract: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
107	0	Add an automated test for the primary success path: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
108	0	Add an automated test for invalid input: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
109	0	Verify database changes are atomic on failure: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
110	0	Verify the user-facing error identifies the corrective action: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
111	0	Review naming and behavior against existing project conventions: Roll counters into parent tasks.	t	42	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
112	0	Confirm the implementation matches the documented contract: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
113	0	Add an automated test for the primary success path: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
114	0	Add an automated test for invalid input: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
115	0	Verify database changes are atomic on failure: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
116	0	Verify the user-facing error identifies the corrective action: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
117	0	Review naming and behavior against existing project conventions: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
118	0	Confirm repeated execution does not create duplicate state: Recalculate leaf counters.	f	43	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
119	0	Confirm the implementation matches the documented contract: Edit requirement definition.	f	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
120	0	Add an automated test for the primary success path: Edit requirement definition.	t	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
121	0	Add an automated test for invalid input: Edit requirement definition.	f	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
122	0	Verify database changes are atomic on failure: Edit requirement definition.	t	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
123	0	Verify the user-facing error identifies the corrective action: Edit requirement definition.	f	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
124	0	Review naming and behavior against existing project conventions: Edit requirement definition.	t	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
125	0	Confirm repeated execution does not create duplicate state: Edit requirement definition.	f	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
126	0	Record observable evidence that the behavior works: Edit requirement definition.	t	44	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
127	0	Confirm the implementation matches the documented contract: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
128	0	Add an automated test for the primary success path: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
129	0	Add an automated test for invalid input: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
130	0	Verify database changes are atomic on failure: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
131	0	Verify the user-facing error identifies the corrective action: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
132	0	Review naming and behavior against existing project conventions: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
133	0	Confirm repeated execution does not create duplicate state: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
134	0	Record observable evidence that the behavior works: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
135	0	Complete peer review of the delivered behavior: Toggle requirement status.	t	45	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
136	0	Confirm the implementation matches the documented contract: Create binary requirement.	f	46	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
137	0	Confirm the implementation matches the documented contract: Summarize phase completeness.	f	47	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
138	0	Add an automated test for the primary success path: Summarize phase completeness.	t	47	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
139	0	Confirm the implementation matches the documented contract: Represent repair work.	t	48	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
140	0	Add an automated test for the primary success path: Represent repair work.	t	48	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
141	0	Add an automated test for invalid input: Represent repair work.	t	48	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
142	0	Confirm the implementation matches the documented contract: Identify production candidates.	f	49	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
143	0	Add an automated test for the primary success path: Identify production candidates.	f	49	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
144	0	Add an automated test for invalid input: Identify production candidates.	f	49	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
145	0	Verify database changes are atomic on failure: Identify production candidates.	f	49	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
146	0	Confirm the implementation matches the documented contract: Identify review backlog.	f	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
147	0	Add an automated test for the primary success path: Identify review backlog.	t	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
148	0	Add an automated test for invalid input: Identify review backlog.	f	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
149	0	Verify database changes are atomic on failure: Identify review backlog.	t	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
150	0	Verify the user-facing error identifies the corrective action: Identify review backlog.	f	50	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
151	0	Confirm the implementation matches the documented contract: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
152	0	Add an automated test for the primary success path: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
153	0	Add an automated test for invalid input: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
154	0	Verify database changes are atomic on failure: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
155	0	Verify the user-facing error identifies the corrective action: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
156	0	Review naming and behavior against existing project conventions: Display task progress card.	t	51	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
157	0	Confirm the implementation matches the documented contract: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
158	0	Add an automated test for the primary success path: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
159	0	Add an automated test for invalid input: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
160	0	Verify database changes are atomic on failure: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
161	0	Verify the user-facing error identifies the corrective action: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
162	0	Review naming and behavior against existing project conventions: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
163	0	Confirm repeated execution does not create duplicate state: Move task between phases.	f	52	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
300	0	Done changes preserve the version.	t	318	2026-06-23 04:39:15.017353+02	2026-06-23 04:39:15.023228+02
164	0	Confirm the implementation matches the documented contract: Group tasks by workflow phase.	f	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
165	0	Add an automated test for the primary success path: Group tasks by workflow phase.	t	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
166	0	Add an automated test for invalid input: Group tasks by workflow phase.	f	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
167	0	Verify database changes are atomic on failure: Group tasks by workflow phase.	t	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
168	0	Verify the user-facing error identifies the corrective action: Group tasks by workflow phase.	f	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
169	0	Review naming and behavior against existing project conventions: Group tasks by workflow phase.	t	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
170	0	Confirm repeated execution does not create duplicate state: Group tasks by workflow phase.	f	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
171	0	Record observable evidence that the behavior works: Group tasks by workflow phase.	t	53	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
172	0	Confirm the implementation matches the documented contract: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
173	0	Add an automated test for the primary success path: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
174	0	Add an automated test for invalid input: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
175	0	Verify database changes are atomic on failure: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
176	0	Verify the user-facing error identifies the corrective action: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
177	0	Review naming and behavior against existing project conventions: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
178	0	Confirm repeated execution does not create duplicate state: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
179	0	Record observable evidence that the behavior works: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
180	0	Complete peer review of the delivered behavior: Document recovery workflow.	t	54	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
181	0	Confirm the implementation matches the documented contract: Return consistent JSON errors.	f	55	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
182	0	Confirm the implementation matches the documented contract: Log structured request context.	f	56	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
183	0	Add an automated test for the primary success path: Log structured request context.	t	56	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
185	0	Add an automated test for the primary success path: Expose health endpoint.	t	57	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
186	0	Add an automated test for invalid input: Expose health endpoint.	t	57	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
187	0	Confirm the implementation matches the documented contract: Test requirement aggregation.	f	58	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
188	0	Add an automated test for the primary success path: Test requirement aggregation.	f	58	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
189	0	Add an automated test for invalid input: Test requirement aggregation.	f	58	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
190	0	Verify database changes are atomic on failure: Test requirement aggregation.	f	58	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
191	0	Confirm the implementation matches the documented contract: Test task concurrency.	f	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
192	0	Add an automated test for the primary success path: Test task concurrency.	t	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
193	0	Add an automated test for invalid input: Test task concurrency.	f	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
194	0	Verify database changes are atomic on failure: Test task concurrency.	t	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
195	0	Verify the user-facing error identifies the corrective action: Test task concurrency.	f	59	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
196	0	Confirm the implementation matches the documented contract: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
197	0	Add an automated test for the primary success path: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
198	0	Add an automated test for invalid input: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
199	0	Verify database changes are atomic on failure: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
200	0	Verify the user-facing error identifies the corrective action: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
201	0	Review naming and behavior against existing project conventions: Test project lifecycle.	t	60	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
303	0	Verify counters reach the parent task.	t	329	2026-06-23 04:39:15.119932+02	2026-06-23 04:39:15.125964+02
184	0	Confirm the implementation matches the documented contract: Expose health endpoint.	f	57	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
302	2	Add requirement toggle endpoint test.	f	324	2026-06-23 04:39:15.049335+02	2026-06-23 04:39:15.090455+02
304	0	Counters follow re-parented tasks.	t	330	2026-06-23 04:39:15.122541+02	2026-06-23 04:39:15.129027+02
308	0	Done changes preserve the version.	t	342	2026-06-23 04:40:06.725839+02	2026-06-23 04:40:06.731423+02
311	0	Verify counters reach the parent task.	t	353	2026-06-23 04:40:06.826575+02	2026-06-23 04:40:06.832992+02
312	0	Counters follow re-parented tasks.	t	354	2026-06-23 04:40:06.829419+02	2026-06-23 04:40:06.835619+02
310	2	Add requirement toggle endpoint test.	f	348	2026-06-23 04:40:06.758039+02	2026-06-23 04:40:06.797996+02
292	0	Done changes preserve the version.	t	294	2026-06-23 04:07:00.067161+02	2026-06-23 04:07:00.07294+02
294	2	Add requirement toggle endpoint test.	f	300	2026-06-23 04:07:00.099347+02	2026-06-23 04:07:00.138525+02
387	0	Task tree delete archives this requirement.	f	569	2026-06-24 16:20:05.139461+02	2026-06-24 16:20:05.139461+02
295	0	Verify counters reach the parent task.	t	305	2026-06-23 04:07:00.166315+02	2026-06-23 04:07:00.172429+02
296	0	Counters follow re-parented tasks.	t	306	2026-06-23 04:07:00.169216+02	2026-06-23 04:07:00.174864+02
\.


--
-- Data for Name: requirement_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requirement_history (id, version, definition, modified, deleted) FROM stdin;
202	0	Add requirement create endpoint test.	2026-06-22 17:38:06.23203+02	f
203	0	Add requirement update endpoint test.	2026-06-22 17:38:06.237842+02	f
203	1	Add requirement update endpoint test.	2026-06-22 17:38:06.250511+02	f
203	2	Text-only update preserves completion state.	2026-06-22 17:38:06.254738+02	f
202	1	Add requirement create endpoint test.	2026-06-22 17:38:06.243289+02	t
203	3	Add requirement toggle endpoint test.	2026-06-22 17:38:06.260858+02	t
204	0	Verify counters reach the parent task.	2026-06-22 17:38:06.296269+02	f
204	1	Verify counters reach the parent task.	2026-06-22 17:38:06.30262+02	t
207	0	Project delete archives this requirement.	2026-06-23 00:01:10.850199+02	t
206	1	Add requirement update endpoint test.	2026-06-23 00:01:10.854219+02	f
206	2	Text-only update preserves completion state.	2026-06-23 00:01:10.858749+02	f
205	1	Add requirement create endpoint test.	2026-06-23 00:01:10.847295+02	t
206	3	Add requirement toggle endpoint test.	2026-06-23 00:01:10.865026+02	t
208	0	Task tree delete archives this requirement.	2026-06-23 00:01:10.892076+02	t
209	1	Verify counters reach the parent task.	2026-06-23 00:01:10.906661+02	t
210	0	Project delete archives this requirement.	2026-06-23 00:01:41.627258+02	t
212	1	Add requirement update endpoint test.	2026-06-23 00:01:41.685588+02	f
212	2	Text-only update preserves completion state.	2026-06-23 00:01:41.690691+02	f
211	1	Add requirement create endpoint test.	2026-06-23 00:01:41.678814+02	t
212	3	Add requirement toggle endpoint test.	2026-06-23 00:01:41.696404+02	t
213	0	Task tree delete archives this requirement.	2026-06-23 00:01:41.729741+02	t
214	1	Verify counters reach the parent task.	2026-06-23 00:01:41.739183+02	t
215	0	Delete the final requirement transactionally.	2026-06-23 00:03:37.182515+02	t
216	0	Project delete archives this requirement.	2026-06-23 00:03:37.200933+02	t
217	0	Require an expected version.	2026-06-23 00:03:37.212696+02	t
219	1	Add requirement update endpoint test.	2026-06-23 00:03:37.256402+02	f
219	2	Text-only update preserves completion state.	2026-06-23 00:03:37.26305+02	f
218	1	Add requirement create endpoint test.	2026-06-23 00:03:37.249259+02	t
219	3	Add requirement toggle endpoint test.	2026-06-23 00:03:37.270632+02	t
220	1	Verify counters reach the parent task.	2026-06-23 00:03:37.319856+02	t
221	0	Task tree delete archives this requirement.	2026-06-23 00:03:37.359669+02	t
222	0	Delete the final requirement transactionally.	2026-06-23 00:05:54.088131+02	t
223	0	Project delete archives this requirement.	2026-06-23 00:05:54.116166+02	t
224	0	Require an expected version.	2026-06-23 00:05:54.149329+02	t
226	1	Add requirement update endpoint test.	2026-06-23 00:05:54.228489+02	f
226	2	Text-only update preserves completion state.	2026-06-23 00:05:54.238676+02	f
225	1	Add requirement create endpoint test.	2026-06-23 00:05:54.216919+02	t
226	3	Add requirement toggle endpoint test.	2026-06-23 00:05:54.250534+02	t
227	1	Verify counters reach the parent task.	2026-06-23 00:05:54.329418+02	t
228	0	Task tree delete archives this requirement.	2026-06-23 00:05:54.381992+02	t
229	0	Delete the final requirement transactionally.	2026-06-23 00:11:52.827519+02	t
230	0	Project delete archives this requirement.	2026-06-23 00:11:52.846914+02	t
231	0	Require an expected version.	2026-06-23 00:11:52.858366+02	t
233	1	Add requirement update endpoint test.	2026-06-23 00:11:52.901106+02	f
233	2	Text-only update preserves completion state.	2026-06-23 00:11:52.906118+02	f
232	1	Add requirement create endpoint test.	2026-06-23 00:11:52.894315+02	t
233	3	Add requirement toggle endpoint test.	2026-06-23 00:11:52.911623+02	t
234	1	Verify counters reach the parent task.	2026-06-23 00:11:52.954197+02	t
235	0	Task tree delete archives this requirement.	2026-06-23 00:11:52.989022+02	t
236	0	Delete the final requirement transactionally.	2026-06-23 00:21:16.527549+02	t
237	0	Project delete archives this requirement.	2026-06-23 00:21:16.54202+02	t
238	0	Require an expected version.	2026-06-23 00:21:16.555909+02	t
240	1	Add requirement update endpoint test.	2026-06-23 00:21:16.598436+02	f
240	2	Text-only update preserves completion state.	2026-06-23 00:21:16.602762+02	f
239	1	Add requirement create endpoint test.	2026-06-23 00:21:16.591407+02	t
240	3	Add requirement toggle endpoint test.	2026-06-23 00:21:16.608682+02	t
241	1	Verify counters reach the parent task.	2026-06-23 00:21:16.650317+02	t
242	0	Task tree delete archives this requirement.	2026-06-23 00:21:16.688527+02	t
243	0	Delete the final requirement transactionally.	2026-06-23 01:38:17.015833+02	t
244	0	Project delete archives this requirement.	2026-06-23 01:38:17.043121+02	t
245	0	Done changes preserve the version.	2026-06-23 01:38:17.057346+02	t
247	0	Add requirement update endpoint test.	2026-06-23 01:38:17.098773+02	f
247	1	Text-only update preserves completion state.	2026-06-23 01:38:17.104076+02	f
246	0	Add requirement create endpoint test.	2026-06-23 01:38:17.092858+02	t
247	2	Add requirement toggle endpoint test.	2026-06-23 01:38:17.115549+02	t
248	0	Verify counters reach the parent task.	2026-06-23 01:38:17.156216+02	t
249	0	Task tree delete archives this requirement.	2026-06-23 01:38:17.210522+02	t
250	0	Project delete archives this requirement.	2026-06-23 01:39:30.00987+02	t
251	0	Delete the final requirement transactionally.	2026-06-23 01:39:30.034887+02	t
252	0	Done changes preserve the version.	2026-06-23 01:39:30.069995+02	t
254	0	Add requirement update endpoint test.	2026-06-23 01:39:30.11209+02	f
254	1	Text-only update preserves completion state.	2026-06-23 01:39:30.117731+02	f
253	0	Add requirement create endpoint test.	2026-06-23 01:39:30.106284+02	t
254	2	Add requirement toggle endpoint test.	2026-06-23 01:39:30.14164+02	t
255	0	Verify counters reach the parent task.	2026-06-23 01:39:30.183232+02	t
256	0	Task tree delete archives this requirement.	2026-06-23 01:39:30.223246+02	t
257	0	Delete the final requirement transactionally.	2026-06-23 01:56:43.638514+02	t
258	0	Project delete archives this requirement.	2026-06-23 01:56:43.655793+02	t
259	0	Done changes preserve the version.	2026-06-23 01:56:43.672551+02	t
261	0	Add requirement update endpoint test.	2026-06-23 01:56:43.713955+02	f
261	1	Text-only update preserves completion state.	2026-06-23 01:56:43.719272+02	f
260	0	Add requirement create endpoint test.	2026-06-23 01:56:43.708157+02	t
261	2	Add requirement toggle endpoint test.	2026-06-23 01:56:43.742314+02	t
262	0	Verify counters reach the parent task.	2026-06-23 01:56:43.782777+02	t
263	0	Task tree delete archives this requirement.	2026-06-23 01:56:43.817227+02	t
266	0	Delete the final requirement transactionally.	2026-06-23 02:29:41.080406+02	t
267	0	Project delete archives this requirement.	2026-06-23 02:29:41.100608+02	t
268	0	Done changes preserve the version.	2026-06-23 02:29:41.114155+02	t
270	0	Add requirement update endpoint test.	2026-06-23 02:29:41.149471+02	f
270	1	Text-only update preserves completion state.	2026-06-23 02:29:41.154237+02	f
269	0	Add requirement create endpoint test.	2026-06-23 02:29:41.143165+02	t
270	2	Add requirement toggle endpoint test.	2026-06-23 02:29:41.176946+02	t
271	0	Verify counters reach the parent task.	2026-06-23 02:29:41.217035+02	t
272	0	Counters follow re-parented tasks.	2026-06-23 02:29:41.276288+02	t
273	0	Task tree delete archives this requirement.	2026-06-23 02:29:41.350719+02	t
274	0	Delete the final requirement transactionally.	2026-06-23 02:33:46.290895+02	t
275	0	Project delete archives this requirement.	2026-06-23 02:33:46.314526+02	t
276	0	Done changes preserve the version.	2026-06-23 02:33:46.336284+02	t
278	0	Add requirement update endpoint test.	2026-06-23 02:33:46.377903+02	f
278	1	Text-only update preserves completion state.	2026-06-23 02:33:46.382733+02	f
277	0	Add requirement create endpoint test.	2026-06-23 02:33:46.371474+02	t
278	2	Add requirement toggle endpoint test.	2026-06-23 02:33:46.404884+02	t
279	0	Verify counters reach the parent task.	2026-06-23 02:33:46.444089+02	t
280	0	Counters follow re-parented tasks.	2026-06-23 02:33:46.452304+02	t
281	0	Task tree delete archives this requirement.	2026-06-23 02:33:46.529432+02	t
282	0	Delete the final requirement transactionally.	2026-06-23 02:41:30.191075+02	t
283	0	Project delete archives this requirement.	2026-06-23 02:41:30.20923+02	t
284	0	Done changes preserve the version.	2026-06-23 02:41:30.226009+02	t
286	0	Add requirement update endpoint test.	2026-06-23 02:41:30.267759+02	f
286	1	Text-only update preserves completion state.	2026-06-23 02:41:30.272648+02	f
285	0	Add requirement create endpoint test.	2026-06-23 02:41:30.261393+02	t
286	2	Add requirement toggle endpoint test.	2026-06-23 02:41:30.296949+02	t
287	0	Verify counters reach the parent task.	2026-06-23 02:41:30.338642+02	t
288	0	Counters follow re-parented tasks.	2026-06-23 02:41:30.347318+02	t
289	0	Task tree delete archives this requirement.	2026-06-23 02:41:30.426158+02	t
290	0	Delete the final requirement transactionally.	2026-06-23 04:07:00.043662+02	t
291	0	Project delete archives this requirement.	2026-06-23 04:07:00.061203+02	t
294	0	Add requirement update endpoint test.	2026-06-23 04:07:00.111061+02	f
294	1	Text-only update preserves completion state.	2026-06-23 04:07:00.116358+02	f
293	0	Add requirement create endpoint test.	2026-06-23 04:07:00.105533+02	t
297	0	Task tree delete archives this requirement.	2026-06-23 04:07:00.244164+02	t
298	0	Delete the final requirement transactionally.	2026-06-23 04:39:14.994223+02	t
299	0	Project delete archives this requirement.	2026-06-23 04:39:15.01211+02	t
302	0	Add requirement update endpoint test.	2026-06-23 04:39:15.061426+02	f
302	1	Text-only update preserves completion state.	2026-06-23 04:39:15.067122+02	f
301	0	Add requirement create endpoint test.	2026-06-23 04:39:15.055847+02	t
305	0	Task tree delete archives this requirement.	2026-06-23 04:39:15.200351+02	t
306	0	Delete the final requirement transactionally.	2026-06-23 04:40:06.703005+02	t
307	0	Project delete archives this requirement.	2026-06-23 04:40:06.720131+02	t
310	0	Add requirement update endpoint test.	2026-06-23 04:40:06.769944+02	f
310	1	Text-only update preserves completion state.	2026-06-23 04:40:06.775058+02	f
309	0	Add requirement create endpoint test.	2026-06-23 04:40:06.763917+02	t
313	0	Task tree delete archives this requirement.	2026-06-23 04:40:06.907978+02	t
314	0	Delete the final requirement transactionally.	2026-06-23 04:46:01.067242+02	t
315	0	Project delete archives this requirement.	2026-06-23 04:46:01.086038+02	t
316	0	Done changes preserve the version.	2026-06-23 04:46:01.109121+02	t
318	0	Add requirement update endpoint test.	2026-06-23 04:46:01.155+02	f
318	1	Text-only update preserves completion state.	2026-06-23 04:46:01.159435+02	f
317	0	Add requirement create endpoint test.	2026-06-23 04:46:01.148534+02	t
318	2	Add requirement toggle endpoint test.	2026-06-23 04:46:01.182755+02	t
319	0	Verify counters reach the parent task.	2026-06-23 04:46:01.241778+02	t
320	0	Counters follow re-parented tasks.	2026-06-23 04:46:01.266275+02	t
321	0	Task tree delete archives this requirement.	2026-06-23 04:46:01.364272+02	t
322	0	Delete the final requirement transactionally.	2026-06-23 05:02:49.495187+02	t
323	0	Project delete archives this requirement.	2026-06-23 05:02:49.518287+02	t
324	0	Done changes preserve the version.	2026-06-23 05:02:49.535394+02	t
326	0	Add requirement update endpoint test.	2026-06-23 05:02:49.582279+02	f
326	1	Text-only update preserves completion state.	2026-06-23 05:02:49.587782+02	f
325	0	Add requirement create endpoint test.	2026-06-23 05:02:49.576735+02	t
326	2	Add requirement toggle endpoint test.	2026-06-23 05:02:49.61057+02	t
327	0	Verify counters reach the parent task.	2026-06-23 05:02:49.66196+02	t
328	0	Counters follow re-parented tasks.	2026-06-23 05:02:49.676567+02	t
329	0	Task tree delete archives this requirement.	2026-06-23 05:02:49.774685+02	t
330	0	Delete the final requirement transactionally.	2026-06-23 05:03:28.538298+02	t
331	0	Project delete archives this requirement.	2026-06-23 05:03:28.566151+02	t
332	0	Done changes preserve the version.	2026-06-23 05:03:28.588131+02	t
334	0	Add requirement update endpoint test.	2026-06-23 05:03:28.641896+02	f
334	1	Text-only update preserves completion state.	2026-06-23 05:03:28.64604+02	f
333	0	Add requirement create endpoint test.	2026-06-23 05:03:28.635042+02	t
334	2	Add requirement toggle endpoint test.	2026-06-23 05:03:28.66943+02	t
335	0	Verify counters reach the parent task.	2026-06-23 05:03:28.722036+02	t
336	0	Counters follow re-parented tasks.	2026-06-23 05:03:28.73629+02	t
337	0	Task tree delete archives this requirement.	2026-06-23 05:03:28.831733+02	t
338	0	Delete the final requirement transactionally.	2026-06-23 12:23:19.535723+02	t
339	0	Project delete archives this requirement.	2026-06-23 12:23:19.55416+02	t
340	0	Done changes preserve the version.	2026-06-23 12:23:19.577676+02	t
342	0	Add requirement update endpoint test.	2026-06-23 12:23:19.626735+02	f
342	1	Text-only update preserves completion state.	2026-06-23 12:23:19.631744+02	f
341	0	Add requirement create endpoint test.	2026-06-23 12:23:19.620225+02	t
342	2	Add requirement toggle endpoint test.	2026-06-23 12:23:19.655586+02	t
343	0	Verify counters reach the parent task.	2026-06-23 12:23:19.707568+02	t
344	0	Counters follow re-parented tasks.	2026-06-23 12:23:19.721704+02	t
345	0	Task tree delete archives this requirement.	2026-06-23 12:23:19.808831+02	t
346	0	Delete the final requirement transactionally.	2026-06-23 12:26:37.987255+02	t
347	0	Project delete archives this requirement.	2026-06-23 12:26:38.006174+02	t
348	0	Done changes preserve the version.	2026-06-23 12:26:38.029232+02	t
350	0	Add requirement update endpoint test.	2026-06-23 12:26:38.076703+02	f
350	1	Text-only update preserves completion state.	2026-06-23 12:26:38.082017+02	f
349	0	Add requirement create endpoint test.	2026-06-23 12:26:38.070372+02	t
350	2	Add requirement toggle endpoint test.	2026-06-23 12:26:38.106459+02	t
351	0	Verify counters reach the parent task.	2026-06-23 12:26:38.161793+02	t
352	0	Counters follow re-parented tasks.	2026-06-23 12:26:38.177239+02	t
353	0	Task tree delete archives this requirement.	2026-06-23 12:26:38.272087+02	t
354	0	Delete the final requirement transactionally.	2026-06-23 12:40:54.439367+02	t
355	0	Project delete archives this requirement.	2026-06-23 12:40:54.457824+02	t
356	0	Done changes preserve the version.	2026-06-23 12:40:54.480406+02	t
358	0	Add requirement update endpoint test.	2026-06-23 12:40:54.526867+02	f
358	1	Text-only update preserves completion state.	2026-06-23 12:40:54.531682+02	f
357	0	Add requirement create endpoint test.	2026-06-23 12:40:54.520495+02	t
358	2	Add requirement toggle endpoint test.	2026-06-23 12:40:54.554355+02	t
359	0	Verify counters reach the parent task.	2026-06-23 12:40:54.605961+02	t
360	0	Counters follow re-parented tasks.	2026-06-23 12:40:54.625909+02	t
361	0	Task tree delete archives this requirement.	2026-06-23 12:40:54.719322+02	t
362	0	Delete the final requirement transactionally.	2026-06-23 12:42:22.105303+02	t
363	0	Project delete archives this requirement.	2026-06-23 12:42:22.129277+02	t
364	0	Done changes preserve the version.	2026-06-23 12:42:22.146882+02	t
366	0	Add requirement update endpoint test.	2026-06-23 12:42:22.195243+02	f
366	1	Text-only update preserves completion state.	2026-06-23 12:42:22.20022+02	f
365	0	Add requirement create endpoint test.	2026-06-23 12:42:22.188776+02	t
366	2	Add requirement toggle endpoint test.	2026-06-23 12:42:22.223897+02	t
367	0	Verify counters reach the parent task.	2026-06-23 12:42:22.277056+02	t
368	0	Counters follow re-parented tasks.	2026-06-23 12:42:22.291679+02	t
369	0	Task tree delete archives this requirement.	2026-06-23 12:42:22.382214+02	t
371	0	Delete the final requirement transactionally.	2026-06-24 16:02:25.29977+02	t
372	0	Project delete archives this requirement.	2026-06-24 16:02:25.311448+02	t
373	0	Done changes preserve the version.	2026-06-24 16:02:25.345134+02	t
375	0	Add requirement update endpoint test.	2026-06-24 16:02:25.391611+02	f
375	1	Text-only update preserves completion state.	2026-06-24 16:02:25.396847+02	f
374	0	Add requirement create endpoint test.	2026-06-24 16:02:25.385334+02	t
375	2	Add requirement toggle endpoint test.	2026-06-24 16:02:25.419973+02	t
376	0	Verify counters reach the parent task.	2026-06-24 16:02:25.47309+02	t
377	0	Counters follow re-parented tasks.	2026-06-24 16:02:25.486604+02	t
370	0	Task tree delete archives this requirement.	2026-06-24 16:02:14.143206+02	t
378	0	Task tree delete archives this requirement.	2026-06-24 16:02:25.578951+02	t
379	0	Delete the final requirement transactionally.	2026-06-24 16:03:18.77293+02	t
380	0	Project delete archives this requirement.	2026-06-24 16:03:18.781372+02	t
381	0	Done changes preserve the version.	2026-06-24 16:03:18.81167+02	t
383	0	Add requirement update endpoint test.	2026-06-24 16:03:18.859438+02	f
383	1	Text-only update preserves completion state.	2026-06-24 16:03:18.863926+02	f
382	0	Add requirement create endpoint test.	2026-06-24 16:03:18.85272+02	t
383	2	Add requirement toggle endpoint test.	2026-06-24 16:03:18.886522+02	t
384	0	Verify counters reach the parent task.	2026-06-24 16:03:18.939067+02	t
385	0	Counters follow re-parented tasks.	2026-06-24 16:03:18.952843+02	t
386	0	Task tree delete archives this requirement.	2026-06-24 16:03:19.062008+02	t
388	0	Delete the final requirement transactionally.	2026-06-24 16:20:31.071612+02	t
389	0	Project delete archives this requirement.	2026-06-24 16:20:31.09211+02	t
390	0	Done changes preserve the version.	2026-06-24 16:20:31.115262+02	t
392	0	Add requirement update endpoint test.	2026-06-24 16:20:31.162853+02	f
392	1	Text-only update preserves completion state.	2026-06-24 16:20:31.168668+02	f
391	0	Add requirement create endpoint test.	2026-06-24 16:20:31.157317+02	t
392	2	Add requirement toggle endpoint test.	2026-06-24 16:20:31.192142+02	t
393	0	Verify counters reach the parent task.	2026-06-24 16:20:31.244491+02	t
394	0	Counters follow re-parented tasks.	2026-06-24 16:20:31.25893+02	t
395	0	Task tree delete archives this requirement.	2026-06-24 16:20:31.34953+02	t
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, version, task_type, name, description, difficulty, priority, task_phase, parent_id, project_id, done_req, total_req, created, modified) FROM stdin;
313	0	task	api-test-requirement-task-1782182354988678310	\N	1	0	backlog	\N	182	0	0	2026-06-23 04:39:14.98893+02	2026-06-23 04:39:14.98893+02
318	0	task	api-test-requirement-task-1782182355011700572	\N	1	0	backlog	\N	185	1	1	2026-06-23 04:39:15.011866+02	2026-06-23 04:39:15.011866+02
324	0	task	api-test-requirement-task-1782182355084574798	\N	1	0	backlog	\N	186	0	1	2026-06-23 04:39:15.084719+02	2026-06-23 04:39:15.084719+02
319	0	task	api-test-requirement-task-1782182355037892473	\N	1	0	backlog	\N	186	0	0	2026-06-23 04:39:15.038082+02	2026-06-23 04:39:15.038082+02
329	0	task	api-test-aggregate-child-1782182355113633131	\N	1	0	backlog	327	190	1	1	2026-06-23 04:39:15.113992+02	2026-06-23 04:39:15.113992+02
327	0	task	api-test-aggregate-parent-1782182355108147426	\N	1	0	backlog	\N	190	1	1	2026-06-23 04:39:15.108259+02	2026-06-23 04:39:15.108259+02
323	0	task	api-test-parent-1782182355081237632	\N	1	0	backlog	\N	188	0	0	2026-06-23 04:39:15.08137+02	2026-06-23 04:39:15.08137+02
325	1	task	api-test-child-1782182355087726793	\N	1	0	backlog	\N	188	0	0	2026-06-23 04:39:15.087962+02	2026-06-23 04:39:15.09336+02
19	0	spike	Document incremental migration ordering	Reserve an ordered path for schema changes after the baseline.	2	124	backlog	7	1	0	1	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
20	0	task	Seed realistic demonstration data	Build a repeatable project dataset for product evaluation.	3	123	progress	7	1	1	2	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
21	0	task	Seed workflow reference values	Install canonical task phases and task types idempotently.	2	122	review	7	1	3	3	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
22	0	task	Define clean database bootstrap	Create the complete schema from a single authoritative script.	4	121	staging	7	1	0	4	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
7	0	feature	Database Lifecycle	Initialize, migrate, and seed PostgreSQL safely.	4	12	staging	1	1	4	10	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
23	0	task	Enable local CORS policy	Allow the configured frontend origin without widening production access.	2	113	staging	8	1	2	5	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
24	0	task	Configure frontend development server	Serve the Quasar application with a working API base URL.	2	112	production	8	1	6	6	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
25	0	task	Configure local API startup	Load configuration and start the Echo service on the expected port.	2	111	production	8	1	0	7	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
8	0	feature	Local Application Runtime	Run the frontend, API, and database consistently.	3	11	production	1	1	8	18	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
1	0	epic	Platform Foundation	Establish the architecture and developer workflow for the product.	5	10	production	\N	1	12	28	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
26	0	task	Refresh workspace data	Reload reference, project, and task data on demand.	2	224	progress	9	1	4	8	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
314	0	task	api-test-history-parent-a-1782182354991249923	\N	1	0	backlog	\N	183	0	0	2026-06-23 04:39:14.991445+02	2026-06-23 04:39:14.991445+02
28	0	task	Render empty workspace state	Explain how to begin when a project contains no tasks.	1	222	staging	9	1	0	1	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
27	0	issue	Preserve navigation errors	Keep backend failures visible without discarding current context.	3	223	closed	9	1	9	9	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
316	4	epic	api-test-history-child-1782182355002635591-renamed	History-bearing description.	8	12	backlog	315	183	0	0	2026-06-23 04:39:15.002937+02	2026-06-23 04:39:15.035432+02
315	0	task	api-test-history-parent-b-1782182354997208506	\N	1	0	backlog	\N	183	0	0	2026-06-23 04:39:14.997337+02	2026-06-23 04:39:14.997337+02
326	0	task	api-test-counter-parent-a-1782182355105256767	\N	1	0	backlog	\N	189	0	0	2026-06-23 04:39:15.105384+02	2026-06-23 04:39:15.105384+02
330	1	task	api-test-counter-child-1782182355116960850	\N	1	0	backlog	328	189	1	1	2026-06-23 04:39:15.117187+02	2026-06-23 04:39:15.13505+02
321	0	task	api-test-phase-sibling-1782182355052664380	\N	1	0	production	320	187	0	0	2026-06-23 04:39:15.052963+02	2026-06-23 04:39:15.052963+02
328	0	task	api-test-counter-parent-b-1782182355110694381	\N	1	0	backlog	\N	189	1	1	2026-06-23 04:39:15.110797+02	2026-06-23 04:39:15.110797+02
320	0	task	api-test-phase-parent-1782182355046658697	\N	1	0	production	\N	187	0	0	2026-06-23 04:39:15.046927+02	2026-06-23 04:39:15.046927+02
333	0	task	api-test-cycle-grandchild-1782182355150651287	\N	1	0	backlog	332	191	0	0	2026-06-23 04:39:15.15085+02	2026-06-23 04:39:15.15085+02
332	0	task	api-test-cycle-child-1782182355146635903	\N	1	0	backlog	331	191	0	0	2026-06-23 04:39:15.146831+02	2026-06-23 04:39:15.146831+02
331	0	task	api-test-cycle-root-1782182355143606431	\N	1	0	backlog	\N	191	0	0	2026-06-23 04:39:15.143729+02	2026-06-23 04:39:15.143729+02
29	0	task	Select active project	Load the task board when the user changes workspaces.	2	221	review	9	1	1	2	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
9	0	feature	Workspace Navigation	Make active work easy to locate and revisit.	2	22	review	2	1	14	20	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
30	0	task	Rename existing project	Validate and persist a project name change.	2	213	review	10	1	3	3	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
31	0	task	List project workspaces	Return stable project results with paging controls.	2	212	production	10	1	0	4	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
32	0	task	Create project endpoint	Persist a named project and return its generated identifier.	2	211	production	10	1	2	5	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
10	0	feature	Project Management	Create and maintain project workspaces.	3	21	production	2	1	5	12	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
2	0	epic	Project Workspace	Provide reliable project organization and navigation.	4	20	staging	\N	1	19	32	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
33	0	task	Order task board consistently	Sort tasks by phase priority and task priority.	2	324	backlog	11	1	6	6	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
34	0	task	Load phase and type options	Read valid workflow choices from reference tables.	2	323	production	11	1	0	7	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
35	0	issue	Reject stale task update	Return a conflict when the supplied task version is outdated.	4	322	review	11	1	4	8	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
337	0	task	api-test-requirement-task-1782182406697386569	\N	1	0	backlog	\N	196	0	0	2026-06-23 04:40:06.697876+02	2026-06-23 04:40:06.697876+02
36	0	task	Edit task metadata	Update name, description, type, difficulty, and priority safely.	3	321	progress	11	1	9	9	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
11	0	feature	Planning Controls	Capture task metadata and workflow intent.	3	32	backlog	3	1	19	30	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
37	0	task	Delete task subtree	Archive and remove a task with all descendants transactionally.	5	313	progress	12	1	0	1	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
342	0	task	api-test-requirement-task-1782182406719729532	\N	1	0	backlog	\N	199	1	1	2026-06-23 04:40:06.719886+02	2026-06-23 04:40:06.719886+02
38	0	task	Create child task	Validate that a child belongs to the same project as its parent.	3	312	review	12	1	1	2	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
39	0	task	Create root task	Create standalone work under a selected project.	2	311	production	12	1	3	3	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
12	0	feature	Task Hierarchy	Break large outcomes into navigable child tasks.	4	31	progress	3	1	4	6	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
3	0	epic	Task Planning	Support structured planning with hierarchical tasks.	5	30	review	\N	1	23	36	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
40	0	task	Verify multi-level aggregation	Prove cached counters match active descendant requirements.	4	424	backlog	13	1	0	4	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
41	0	task	Render derived completion percentage	Calculate progress safely when total requirements are zero.	3	423	staging	13	1	2	5	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
353	0	task	api-test-aggregate-child-1782182406820913910	\N	1	0	backlog	351	204	1	1	2026-06-23 04:40:06.82114+02	2026-06-23 04:40:06.82114+02
351	0	task	api-test-aggregate-parent-1782182406815011664	\N	1	0	backlog	\N	204	1	1	2026-06-23 04:40:06.815146+02	2026-06-23 04:40:06.815146+02
42	0	task	Roll counters into parent tasks	Propagate descendant counts to every ancestor.	5	422	progress	13	1	6	6	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
43	0	task	Recalculate leaf counters	Count completed and total requirements for a leaf task.	3	421	review	13	1	0	7	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
13	0	feature	Progress Aggregation	Roll requirement progress through the task tree.	5	42	review	4	1	8	22	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
44	0	task	Edit requirement definition	Preserve history while changing verification text.	3	413	review	14	1	4	8	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
348	0	task	api-test-requirement-task-1782182406792035930	\N	1	0	backlog	\N	200	0	1	2026-06-23 04:40:06.79216+02	2026-06-23 04:40:06.79216+02
343	0	task	api-test-requirement-task-1782182406746514178	\N	1	0	backlog	\N	200	0	0	2026-06-23 04:40:06.746688+02	2026-06-23 04:40:06.746688+02
45	0	task	Toggle requirement status	Mark a requirement done or incomplete transactionally.	3	412	production	14	1	9	9	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
46	0	task	Create binary requirement	Attach a concrete definition of done to a task.	2	411	production	14	1	0	1	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
14	0	feature	Requirement Management	Maintain binary definitions of done.	4	41	production	4	1	13	18	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
4	0	epic	Completeness Engine	Measure delivery through concrete verified requirements.	5	40	progress	\N	1	21	40	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
47	0	feature	Summarize phase completeness	Aggregate requirement counters for each workflow phase.	4	524	backlog	15	1	1	2	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
57	0	task	Expose health endpoint	Report API and database availability to local clients.	2	621	production	17	1	2	3	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
289	0	task	api-test-requirement-task-1782180420036769101	\N	1	0	backlog	\N	168	0	0	2026-06-23 04:07:00.037113+02	2026-06-23 04:07:00.037113+02
49	0	feature	Identify production candidates	Show fully complete work approaching production.	3	522	backlog	15	1	0	4	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
48	0	issue	Represent repair work	Keep production repair tasks visible in a dedicated phase.	3	523	closed	15	1	3	3	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
50	0	feature	Identify review backlog	Surface review work with incomplete requirements.	3	521	backlog	15	1	2	5	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
15	0	feature	Release Readiness	Expose work that is ready for staging and production.	4	52	backlog	5	1	6	14	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
17	0	feature	Runtime Diagnostics	Make service and database failures understandable.	3	62	backlog	6	1	12	15	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
51	0	task	Display task progress card	Show task type and derived completeness on the board.	2	513	staging	16	1	6	6	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
52	0	task	Move task between phases	Validate and persist a version-guarded phase change.	3	512	review	16	1	0	7	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
294	0	task	api-test-requirement-task-1782180420060788083	\N	1	0	backlog	\N	171	1	1	2026-06-23 04:07:00.060954+02	2026-06-23 04:07:00.060954+02
53	0	task	Group tasks by workflow phase	Render one board column for each seeded phase.	3	511	progress	16	1	4	8	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
16	0	feature	Phase Board	Visualize and change the current delivery phase.	3	51	progress	5	1	10	21	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
5	0	epic	Delivery Workflow	Move planned work through a visible delivery lifecycle.	4	50	backlog	\N	1	16	35	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
54	0	task	Document recovery workflow	Describe how to rebuild and reseed a local database.	2	624	backlog	17	1	9	9	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
55	0	task	Return consistent JSON errors	Map validation, missing data, and conflicts to clear responses.	3	623	review	17	1	0	1	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
340	4	epic	api-test-history-child-1782182406711285760-renamed	History-bearing description.	8	12	backlog	339	197	0	0	2026-06-23 04:40:06.711528+02	2026-06-23 04:40:06.743774+02
56	0	task	Log structured request context	Record request path, status, and failures with zerolog.	2	622	staging	17	1	1	2	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
339	0	task	api-test-history-parent-b-1782182406705950449	\N	1	0	backlog	\N	197	0	0	2026-06-23 04:40:06.706067+02	2026-06-23 04:40:06.706067+02
345	0	task	api-test-phase-sibling-1782182406760577119	\N	1	0	production	344	201	0	0	2026-06-23 04:40:06.760807+02	2026-06-23 04:40:06.760807+02
58	0	task	Test requirement aggregation	Verify requirement changes update every task ancestor.	4	613	review	18	1	0	4	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
347	0	task	api-test-parent-1782182406789294495	\N	1	0	backlog	\N	202	0	0	2026-06-23 04:40:06.78941+02	2026-06-23 04:40:06.78941+02
300	0	task	api-test-requirement-task-1782180420132678716	\N	1	0	backlog	\N	172	0	1	2026-06-23 04:07:00.132864+02	2026-06-23 04:07:00.132864+02
59	0	task	Test task concurrency	Prove stale task writes cannot overwrite current data.	4	612	progress	18	1	2	5	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
295	0	task	api-test-requirement-task-1782180420087698315	\N	1	0	backlog	\N	172	0	0	2026-06-23 04:07:00.087871+02	2026-06-23 04:07:00.087871+02
349	1	task	api-test-child-1782182406794771183	\N	1	0	backlog	\N	202	0	0	2026-06-23 04:40:06.794952+02	2026-06-23 04:40:06.800932+02
305	0	task	api-test-aggregate-child-1782180420161056564	\N	1	0	backlog	303	176	1	1	2026-06-23 04:07:00.161237+02	2026-06-23 04:07:00.161237+02
303	0	task	api-test-aggregate-parent-1782180420155143057	\N	1	0	backlog	\N	176	1	1	2026-06-23 04:07:00.155277+02	2026-06-23 04:07:00.155277+02
338	0	task	api-test-history-parent-a-1782182406699938334	\N	1	0	backlog	\N	197	0	0	2026-06-23 04:40:06.700144+02	2026-06-23 04:40:06.700144+02
344	0	task	api-test-phase-parent-1782182406754785582	\N	1	0	production	\N	201	0	0	2026-06-23 04:40:06.755032+02	2026-06-23 04:40:06.755032+02
350	0	task	api-test-counter-parent-a-1782182406812413090	\N	1	0	backlog	\N	203	0	0	2026-06-23 04:40:06.812547+02	2026-06-23 04:40:06.812547+02
354	1	task	api-test-counter-child-1782182406823911672	\N	1	0	backlog	352	203	1	1	2026-06-23 04:40:06.824064+02	2026-06-23 04:40:06.841622+02
357	0	task	api-test-cycle-grandchild-1782182406856575992	\N	1	0	backlog	356	205	0	0	2026-06-23 04:40:06.856721+02	2026-06-23 04:40:06.856721+02
356	0	task	api-test-cycle-child-1782182406853341320	\N	1	0	backlog	355	205	0	0	2026-06-23 04:40:06.853462+02	2026-06-23 04:40:06.853462+02
355	0	task	api-test-cycle-root-1782182406850402811	\N	1	0	backlog	\N	205	0	0	2026-06-23 04:40:06.850509+02	2026-06-23 04:40:06.850509+02
352	0	task	api-test-counter-parent-b-1782182406817785530	\N	1	0	backlog	\N	203	1	1	2026-06-23 04:40:06.817886+02	2026-06-23 04:40:06.817886+02
6	0	epic	Quality and Operations	Keep the application observable, tested, and recoverable.	4	60	backlog	\N	1	20	30	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
60	0	task	Test project lifecycle	Cover project create, read, update, and delete behavior.	3	611	closed	18	1	6	6	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
309	0	task	api-test-cycle-grandchild-1782180420195036369	\N	1	0	backlog	308	177	0	0	2026-06-23 04:07:00.195175+02	2026-06-23 04:07:00.195175+02
308	0	task	api-test-cycle-child-1782180420191717428	\N	1	0	backlog	307	177	0	0	2026-06-23 04:07:00.191889+02	2026-06-23 04:07:00.191889+02
307	0	task	api-test-cycle-root-1782180420188660684	\N	1	0	backlog	\N	177	0	0	2026-06-23 04:07:00.18877+02	2026-06-23 04:07:00.18877+02
18	0	feature	Automated Verification	Protect core behavior with repeatable tests.	4	61	closed	6	1	8	15	2026-06-22 17:35:43.694172+02	2026-06-22 17:35:43.694172+02
290	0	task	api-test-history-parent-a-1782180420039722248	\N	1	0	backlog	\N	169	0	0	2026-06-23 04:07:00.039912+02	2026-06-23 04:07:00.039912+02
292	4	epic	api-test-history-child-1782180420052251886-renamed	History-bearing description.	8	12	backlog	291	169	0	0	2026-06-23 04:07:00.052523+02	2026-06-23 04:07:00.085286+02
291	0	task	api-test-history-parent-b-1782180420046580389	\N	1	0	backlog	\N	169	0	0	2026-06-23 04:07:00.04674+02	2026-06-23 04:07:00.04674+02
297	0	task	api-test-phase-sibling-1782180420102130196	\N	1	0	production	296	173	0	0	2026-06-23 04:07:00.102364+02	2026-06-23 04:07:00.102364+02
296	0	task	api-test-phase-parent-1782180420096662906	\N	1	0	production	\N	173	0	0	2026-06-23 04:07:00.096953+02	2026-06-23 04:07:00.096953+02
299	0	task	api-test-parent-1782180420129908436	\N	1	0	backlog	\N	174	0	0	2026-06-23 04:07:00.130063+02	2026-06-23 04:07:00.130063+02
301	1	task	api-test-child-1782180420135387399	\N	1	0	backlog	\N	174	0	0	2026-06-23 04:07:00.135581+02	2026-06-23 04:07:00.141061+02
302	0	task	api-test-counter-parent-a-1782180420152513484	\N	1	0	backlog	\N	175	0	0	2026-06-23 04:07:00.152612+02	2026-06-23 04:07:00.152612+02
306	1	task	api-test-counter-child-1782180420163618639	\N	1	0	backlog	304	175	1	1	2026-06-23 04:07:00.163793+02	2026-06-23 04:07:00.180767+02
304	0	task	api-test-counter-parent-b-1782180420158015250	\N	1	0	backlog	\N	175	1	1	2026-06-23 04:07:00.158138+02	2026-06-23 04:07:00.158138+02
\.


--
-- Data for Name: task_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_history (id, version, task_type, name, description, parent_id, modified, deleted) FROM stdin;
61	0	task	api-test-project-delete-task-1782142686205628331	\N	\N	2026-06-22 17:38:06.206243+02	t
63	0	task	api-test-task-1782142686228789838	Created by task API integration test.	\N	2026-06-22 17:38:06.22938+02	f
63	1	epic	api-test-task-1782142686228789838-updated	Updated by task API integration test.	\N	2026-06-22 17:38:06.23568+02	f
63	2	epic	api-test-task-1782142686228789838-updated	Updated by task API integration test.	\N	2026-06-22 17:38:06.241615+02	t
62	0	task	api-test-requirement-task-1782142686226203006	\N	\N	2026-06-22 17:38:06.266811+02	t
64	0	task	api-test-parent-task-1782142686275579137	\N	\N	2026-06-22 17:38:06.275792+02	t
65	0	task	api-test-child-task-1782142686281478448	\N	64	2026-06-22 17:38:06.28172+02	t
67	0	task	api-test-aggregate-child-1782142686290131988	\N	66	2026-06-22 17:38:06.30262+02	t
66	0	task	api-test-aggregate-parent-1782142686284191729	\N	\N	2026-06-22 17:38:06.30262+02	t
73	0	task	api-test-task-1782165670829961222	Created by task API integration test.	\N	2026-06-23 00:01:10.830276+02	f
73	2	epic	api-test-task-1782165670829961222-updated	Updated by task API integration test.	\N	2026-06-23 00:01:10.845748+02	t
74	0	task	api-test-project-delete-task-1782165670844087564	\N	\N	2026-06-23 00:01:10.844312+02	t
72	0	task	api-test-requirement-task-1782165670830002861	\N	\N	2026-06-23 00:01:10.830269+02	t
75	0	task	api-test-parent-task-1782165670879746169	\N	\N	2026-06-23 00:01:10.879895+02	t
76	0	task	api-test-child-task-1782165670885766160	\N	75	2026-06-23 00:01:10.886109+02	t
78	0	task	api-test-aggregate-child-1782165670894346732	\N	77	2026-06-23 00:01:10.894601+02	t
77	0	task	api-test-aggregate-parent-1782165670889116782	\N	\N	2026-06-23 00:01:10.889288+02	t
79	0	task	api-test-project-delete-task-1782165701622125672	\N	\N	2026-06-23 00:01:41.622374+02	t
81	0	task	api-test-task-1782165701669311665	Created by task API integration test.	\N	2026-06-23 00:01:41.66957+02	f
81	2	epic	api-test-task-1782165701669311665-updated	Updated by task API integration test.	\N	2026-06-23 00:01:41.682962+02	t
80	0	task	api-test-requirement-task-1782165701662722233	\N	\N	2026-06-23 00:01:41.662958+02	t
82	0	task	api-test-parent-task-1782165701717661778	\N	\N	2026-06-23 00:01:41.71786+02	t
84	0	task	api-test-child-task-1782165701723836883	\N	82	2026-06-23 00:01:41.72416+02	t
85	0	task	api-test-aggregate-child-1782165701726742811	\N	83	2026-06-23 00:01:41.726975+02	t
83	0	task	api-test-aggregate-parent-1782165701720611720	\N	\N	2026-06-23 00:01:41.72093+02	t
86	0	task	api-test-requirement-task-1782165817176569504	\N	\N	2026-06-23 00:03:37.177038+02	t
89	0	task	api-test-history-child-1782165817191122096	\N	87	2026-06-23 00:03:37.191359+02	f
89	1	task	api-test-history-child-1782165817191122096-renamed	\N	87	2026-06-23 00:03:37.198141+02	f
90	0	task	api-test-project-delete-task-1782165817194467207	\N	\N	2026-06-23 00:03:37.194642+02	t
89	2	task	api-test-history-child-1782165817191122096-renamed	History-bearing description.	87	2026-06-23 00:03:37.203839+02	f
89	3	epic	api-test-history-child-1782165817191122096-renamed	History-bearing description.	87	2026-06-23 00:03:37.21078+02	f
91	0	task	api-test-requirement-task-1782165817206435492	\N	\N	2026-06-23 00:03:37.206608+02	t
87	0	task	api-test-history-parent-a-1782165817179138262	\N	\N	2026-06-23 00:03:37.179306+02	t
88	0	task	api-test-history-parent-b-1782165817185891985	\N	\N	2026-06-23 00:03:37.186102+02	t
89	5	epic	api-test-history-child-1782165817191122096-renamed	History-bearing description.	88	2026-06-23 00:03:37.222157+02	t
95	1	task	api-test-phase-child-1782165817252225404	\N	93	2026-06-23 00:03:37.260199+02	t
93	0	task	api-test-phase-parent-1782165817239749315	\N	\N	2026-06-23 00:03:37.239998+02	t
94	0	task	api-test-phase-sibling-1782165817245965909	\N	93	2026-06-23 00:03:37.246209+02	t
92	0	task	api-test-requirement-task-1782165817230943997	\N	\N	2026-06-23 00:03:37.231057+02	t
96	0	task	api-test-missing-version-1782165817288700911	\N	\N	2026-06-23 00:03:37.288847+02	t
99	0	task	api-test-task-1782165817310239587	Created by task API integration test.	\N	2026-06-23 00:03:37.310376+02	f
97	0	task	api-test-aggregate-parent-1782165817301359777	\N	\N	2026-06-23 00:03:37.301506+02	t
98	0	task	api-test-aggregate-child-1782165817307530563	\N	97	2026-06-23 00:03:37.307656+02	t
99	2	epic	api-test-task-1782165817310239587-updated	Updated by task API integration test.	\N	2026-06-23 00:03:37.3233+02	t
100	0	task	api-test-parent-task-1782165817351580061	\N	\N	2026-06-23 00:03:37.351693+02	t
101	0	task	api-test-child-task-1782165817355349358	\N	100	2026-06-23 00:03:37.355493+02	t
104	0	task	api-test-requirement-task-1782165954077090486	\N	\N	2026-06-23 00:05:54.077432+02	t
107	0	task	api-test-history-child-1782165954104905329	\N	105	2026-06-23 00:05:54.105203+02	f
108	0	task	api-test-project-delete-task-1782165954104862588	\N	\N	2026-06-23 00:05:54.105088+02	t
107	1	task	api-test-history-child-1782165954104905329-renamed	\N	105	2026-06-23 00:05:54.116126+02	f
107	2	task	api-test-history-child-1782165954104905329-renamed	History-bearing description.	105	2026-06-23 00:05:54.131868+02	f
106	0	task	api-test-history-parent-b-1782165954093316886	\N	\N	2026-06-23 00:05:54.093494+02	t
107	3	epic	api-test-history-child-1782165954104905329-renamed	History-bearing description.	105	2026-06-23 00:05:54.14438+02	t
105	0	task	api-test-history-parent-a-1782165954082991461	\N	\N	2026-06-23 00:05:54.083178+02	t
109	0	task	api-test-requirement-task-1782165954138572183	\N	\N	2026-06-23 00:05:54.138759+02	t
113	1	task	api-test-phase-child-1782165954199608574	\N	110	2026-06-23 00:05:54.211149+02	t
112	0	task	api-test-phase-sibling-1782165954188644978	\N	110	2026-06-23 00:05:54.188934+02	t
110	0	task	api-test-phase-parent-1782165954177316598	\N	\N	2026-06-23 00:05:54.177643+02	t
114	0	task	api-test-missing-version-1782165954255788484	\N	\N	2026-06-23 00:05:54.255946+02	t
111	0	task	api-test-requirement-task-1782165954182694569	\N	\N	2026-06-23 00:05:54.182843+02	t
115	0	task	api-test-task-1782165954289761099	Created by task API integration test.	\N	2026-06-23 00:05:54.289904+02	f
115	2	epic	api-test-task-1782165954289761099-updated	Updated by task API integration test.	\N	2026-06-23 00:05:54.313462+02	t
117	0	task	api-test-aggregate-child-1782165954306882979	\N	116	2026-06-23 00:05:54.307181+02	t
116	0	task	api-test-aggregate-parent-1782165954295019764	\N	\N	2026-06-23 00:05:54.295164+02	t
118	0	task	api-test-parent-task-1782165954371085872	\N	\N	2026-06-23 00:05:54.371202+02	t
119	0	task	api-test-child-task-1782165954376324469	\N	118	2026-06-23 00:05:54.376519+02	t
123	0	task	api-test-history-child-1782166312833577129	\N	120	2026-06-23 00:11:52.833875+02	f
121	0	task	api-test-requirement-task-1782166312821323653	\N	\N	2026-06-23 00:11:52.821619+02	t
123	1	task	api-test-history-child-1782166312833577129-renamed	\N	120	2026-06-23 00:11:52.837488+02	f
123	2	task	api-test-history-child-1782166312833577129-renamed	History-bearing description.	120	2026-06-23 00:11:52.844234+02	f
124	0	task	api-test-project-delete-task-1782166312840122327	\N	\N	2026-06-23 00:11:52.84042+02	t
123	3	epic	api-test-history-child-1782166312833577129-renamed	History-bearing description.	120	2026-06-23 00:11:52.849828+02	f
125	0	task	api-test-requirement-task-1782166312852257839	\N	\N	2026-06-23 00:11:52.852447+02	t
120	0	task	api-test-history-parent-a-1782166312821258089	\N	\N	2026-06-23 00:11:52.821612+02	t
123	5	epic	api-test-history-child-1782166312833577129-renamed	History-bearing description.	122	2026-06-23 00:11:52.861111+02	t
122	0	task	api-test-history-parent-b-1782166312827353482	\N	\N	2026-06-23 00:11:52.827515+02	t
129	1	task	api-test-phase-child-1782166312891022272	\N	127	2026-06-23 00:11:52.897577+02	t
128	0	task	api-test-phase-sibling-1782166312884978907	\N	127	2026-06-23 00:11:52.885224+02	t
127	0	task	api-test-phase-parent-1782166312879227717	\N	\N	2026-06-23 00:11:52.879461+02	t
126	0	task	api-test-requirement-task-1782166312876361104	\N	\N	2026-06-23 00:11:52.876541+02	t
130	0	task	api-test-missing-version-1782166312920694321	\N	\N	2026-06-23 00:11:52.920865+02	t
132	0	task	api-test-task-1782166312939091131	Created by task API integration test.	\N	2026-06-23 00:11:52.939252+02	f
132	2	epic	api-test-task-1782166312939091131-updated	Updated by task API integration test.	\N	2026-06-23 00:11:52.952766+02	t
133	0	task	api-test-aggregate-child-1782166312942088753	\N	131	2026-06-23 00:11:52.942276+02	t
131	0	task	api-test-aggregate-parent-1782166312935495013	\N	\N	2026-06-23 00:11:52.935652+02	t
134	0	task	api-test-parent-task-1782166312982157933	\N	\N	2026-06-23 00:11:52.982271+02	t
135	0	task	api-test-child-task-1782166312985227021	\N	134	2026-06-23 00:11:52.98539+02	t
136	0	task	api-test-requirement-task-1782166876521232841	\N	\N	2026-06-23 00:21:16.521471+02	t
140	0	task	api-test-history-child-1782166876535794270	\N	137	2026-06-23 00:21:16.536106+02	f
139	0	task	api-test-project-delete-task-1782166876535749104	\N	\N	2026-06-23 00:21:16.535924+02	t
140	1	task	api-test-history-child-1782166876535794270-renamed	\N	137	2026-06-23 00:21:16.541926+02	f
140	2	task	api-test-history-child-1782166876535794270-renamed	History-bearing description.	137	2026-06-23 00:21:16.548183+02	f
140	3	epic	api-test-history-child-1782166876535794270-renamed	History-bearing description.	137	2026-06-23 00:21:16.553882+02	f
141	0	task	api-test-requirement-task-1782166876550552041	\N	\N	2026-06-23 00:21:16.550712+02	t
137	0	task	api-test-history-parent-a-1782166876524260159	\N	\N	2026-06-23 00:21:16.524582+02	t
138	0	task	api-test-history-parent-b-1782166876530029223	\N	\N	2026-06-23 00:21:16.53017+02	t
140	5	epic	api-test-history-child-1782166876535794270-renamed	History-bearing description.	138	2026-06-23 00:21:16.564991+02	t
145	1	task	api-test-phase-child-1782166876594275900	\N	143	2026-06-23 00:21:16.600681+02	t
144	0	task	api-test-phase-sibling-1782166876588340140	\N	143	2026-06-23 00:21:16.588628+02	t
143	0	task	api-test-phase-parent-1782166876582526000	\N	\N	2026-06-23 00:21:16.582802+02	t
142	0	task	api-test-requirement-task-1782166876574154204	\N	\N	2026-06-23 00:21:16.574293+02	t
146	0	task	api-test-missing-version-1782166876623026059	\N	\N	2026-06-23 00:21:16.623153+02	t
149	0	task	api-test-task-1782166876641022739	Created by task API integration test.	\N	2026-06-23 00:21:16.64111+02	f
148	0	task	api-test-aggregate-child-1782166876637722814	\N	147	2026-06-23 00:21:16.63809+02	t
147	0	task	api-test-aggregate-parent-1782166876631863699	\N	\N	2026-06-23 00:21:16.631979+02	t
149	2	epic	api-test-task-1782166876641022739-updated	Updated by task API integration test.	\N	2026-06-23 00:21:16.65401+02	t
150	0	task	api-test-parent-task-1782166876681211296	\N	\N	2026-06-23 00:21:16.681306+02	t
151	0	task	api-test-child-task-1782166876684785383	\N	150	2026-06-23 00:21:16.684969+02	t
152	0	task	api-test-requirement-task-1782171497009655474	\N	\N	2026-06-23 01:38:17.010053+02	t
154	0	task	api-test-project-delete-task-1782171497036785107	\N	\N	2026-06-23 01:38:17.037215+02	t
157	0	task	api-test-history-child-1782171497048537913	\N	153	2026-06-23 01:38:17.048869+02	f
157	1	task	api-test-history-child-1782171497048537913-renamed	\N	153	2026-06-23 01:38:17.054541+02	f
156	0	task	api-test-requirement-task-1782171497045779956	\N	\N	2026-06-23 01:38:17.045949+02	t
157	2	task	api-test-history-child-1782171497048537913-renamed	History-bearing description.	153	2026-06-23 01:38:17.060575+02	f
157	3	epic	api-test-history-child-1782171497048537913-renamed	History-bearing description.	153	2026-06-23 01:38:17.066532+02	f
153	0	task	api-test-history-parent-a-1782171497036780548	\N	\N	2026-06-23 01:38:17.037131+02	t
157	4	epic	api-test-history-child-1782171497048537913-renamed	History-bearing description.	155	2026-06-23 01:38:17.077976+02	t
155	0	task	api-test-history-parent-b-1782171497042930636	\N	\N	2026-06-23 01:38:17.043105+02	t
161	0	task	api-test-phase-child-1782171497106593777	\N	159	2026-06-23 01:38:17.113196+02	t
160	0	task	api-test-phase-sibling-1782171497101042667	\N	159	2026-06-23 01:38:17.101315+02	t
159	0	task	api-test-phase-parent-1782171497095121755	\N	\N	2026-06-23 01:38:17.095417+02	t
158	0	task	api-test-requirement-task-1782171497074744864	\N	\N	2026-06-23 01:38:17.074911+02	t
164	0	task	api-test-child-1782171497140962205	\N	162	2026-06-23 01:38:17.14111+02	f
162	0	task	api-test-parent-1782171497135631273	\N	\N	2026-06-23 01:38:17.135793+02	t
164	1	task	api-test-child-1782171497140962205	\N	\N	2026-06-23 01:38:17.147208+02	t
165	0	task	api-test-aggregate-child-1782171497144276257	\N	163	2026-06-23 01:38:17.144566+02	t
163	0	task	api-test-aggregate-parent-1782171497138386835	\N	\N	2026-06-23 01:38:17.138555+02	t
166	0	task	api-test-task-1782171497167651251	Created by task API integration test.	\N	2026-06-23 01:38:17.167841+02	f
166	1	epic	api-test-task-1782171497167651251-updated	Updated by task API integration test.	\N	2026-06-23 01:38:17.178343+02	t
167	0	task	api-test-parent-task-1782171497202808797	\N	\N	2026-06-23 01:38:17.202947+02	t
168	0	task	api-test-child-task-1782171497206260461	\N	167	2026-06-23 01:38:17.206942+02	t
169	0	task	api-test-project-delete-task-1782171570003658863	\N	\N	2026-06-23 01:39:30.004068+02	t
170	0	task	api-test-requirement-task-1782171570030918132	\N	\N	2026-06-23 01:39:30.031099+02	t
173	0	task	api-test-history-child-1782171570049537657	\N	171	2026-06-23 01:39:30.049789+02	f
173	1	task	api-test-history-child-1782171570049537657-renamed	\N	171	2026-06-23 01:39:30.055899+02	f
173	2	task	api-test-history-child-1782171570049537657-renamed	History-bearing description.	171	2026-06-23 01:39:30.061787+02	f
173	3	epic	api-test-history-child-1782171570049537657-renamed	History-bearing description.	171	2026-06-23 01:39:30.067958+02	f
174	0	task	api-test-requirement-task-1782171570058432045	\N	\N	2026-06-23 01:39:30.058576+02	t
179	0	task	api-test-requirement-task-1782171570135016761	\N	\N	2026-06-23 01:39:30.135143+02	t
175	0	task	api-test-requirement-task-1782171570088511439	\N	\N	2026-06-23 01:39:30.08864+02	t
183	0	task	api-test-aggregate-child-1782171570170361052	\N	182	2026-06-23 01:39:30.170585+02	t
182	0	task	api-test-aggregate-parent-1782171570165174975	\N	\N	2026-06-23 01:39:30.1653+02	t
171	0	task	api-test-history-parent-a-1782171570037466657	\N	\N	2026-06-23 01:39:30.037762+02	t
173	4	epic	api-test-history-child-1782171570049537657-renamed	History-bearing description.	172	2026-06-23 01:39:30.08497+02	t
172	0	task	api-test-history-parent-b-1782171570043519539	\N	\N	2026-06-23 01:39:30.043649+02	t
178	0	task	api-test-phase-child-1782171570114331785	\N	176	2026-06-23 01:39:30.121043+02	t
177	0	task	api-test-phase-sibling-1782171570108789071	\N	176	2026-06-23 01:39:30.109089+02	t
176	0	task	api-test-phase-parent-1782171570102534956	\N	\N	2026-06-23 01:39:30.102806+02	t
181	0	task	api-test-child-1782171570150059233	\N	180	2026-06-23 01:39:30.150237+02	f
180	0	task	api-test-parent-1782171570144158419	\N	\N	2026-06-23 01:39:30.1443+02	t
181	1	task	api-test-child-1782171570150059233	\N	\N	2026-06-23 01:39:30.156136+02	t
184	0	task	api-test-task-1782171570174329367	Created by task API integration test.	\N	2026-06-23 01:39:30.174453+02	f
184	1	epic	api-test-task-1782171570174329367-updated	Updated by task API integration test.	\N	2026-06-23 01:39:30.187092+02	t
185	0	task	api-test-parent-task-1782171570216026189	\N	\N	2026-06-23 01:39:30.216154+02	t
186	0	task	api-test-child-task-1782171570219886589	\N	185	2026-06-23 01:39:30.220056+02	t
187	0	task	api-test-requirement-task-1782172603631825173	\N	\N	2026-06-23 01:56:43.632181+02	t
190	0	task	api-test-history-child-1782172603646701019	\N	188	2026-06-23 01:56:43.647+02	f
190	1	task	api-test-history-child-1782172603646701019-renamed	\N	188	2026-06-23 01:56:43.652519+02	f
191	0	task	api-test-project-delete-task-1782172603649322827	\N	\N	2026-06-23 01:56:43.649478+02	t
190	2	task	api-test-history-child-1782172603646701019-renamed	History-bearing description.	188	2026-06-23 01:56:43.658794+02	f
190	3	epic	api-test-history-child-1782172603646701019-renamed	History-bearing description.	188	2026-06-23 01:56:43.664517+02	f
192	0	task	api-test-requirement-task-1782172603660620098	\N	\N	2026-06-23 01:56:43.660755+02	t
188	0	task	api-test-history-parent-a-1782172603635040138	\N	\N	2026-06-23 01:56:43.635362+02	t
190	4	epic	api-test-history-child-1782172603646701019-renamed	History-bearing description.	189	2026-06-23 01:56:43.680891+02	t
189	0	task	api-test-history-parent-b-1782172603641061140	\N	\N	2026-06-23 01:56:43.641287+02	t
196	0	task	api-test-phase-child-1782172603710660683	\N	194	2026-06-23 01:56:43.716499+02	t
195	0	task	api-test-phase-sibling-1782172603704544710	\N	194	2026-06-23 01:56:43.704806+02	t
194	0	task	api-test-phase-parent-1782172603699127544	\N	\N	2026-06-23 01:56:43.699373+02	t
199	0	task	api-test-child-1782172603745230773	\N	198	2026-06-23 01:56:43.745457+02	f
197	0	task	api-test-requirement-task-1782172603736330584	\N	\N	2026-06-23 01:56:43.736448+02	t
193	0	task	api-test-requirement-task-1782172603690375005	\N	\N	2026-06-23 01:56:43.690568+02	t
199	1	task	api-test-child-1782172603745230773	\N	\N	2026-06-23 01:56:43.750684+02	t
198	0	task	api-test-parent-1782172603739095754	\N	\N	2026-06-23 01:56:43.739285+02	t
201	0	task	api-test-task-1782172603768335032	Created by task API integration test.	\N	2026-06-23 01:56:43.768468+02	f
201	1	epic	api-test-task-1782172603768335032-updated	Updated by task API integration test.	\N	2026-06-23 01:56:43.780823+02	t
202	0	task	api-test-aggregate-child-1782172603771013879	\N	200	2026-06-23 01:56:43.771426+02	t
200	0	task	api-test-aggregate-parent-1782172603765328835	\N	\N	2026-06-23 01:56:43.765492+02	t
203	0	task	api-test-parent-task-1782172603809986108	\N	\N	2026-06-23 01:56:43.810083+02	t
204	0	task	api-test-child-task-1782172603813571395	\N	203	2026-06-23 01:56:43.813735+02	t
217	0	task	api-test-requirement-task-1782174581074228393	\N	\N	2026-06-23 02:29:41.074634+02	t
218	0	task	api-test-project-delete-task-1782174581092220035	\N	\N	2026-06-23 02:29:41.092504+02	t
219	0	task	api-test-requirement-task-1782174581102962742	\N	\N	2026-06-23 02:29:41.103173+02	t
223	0	task	api-test-history-child-1782174581145850947	\N	221	2026-06-23 02:29:41.14611+02	f
223	1	task	api-test-history-child-1782174581145850947-renamed	\N	221	2026-06-23 02:29:41.151551+02	f
223	2	task	api-test-history-child-1782174581145850947-renamed	History-bearing description.	221	2026-06-23 02:29:41.157953+02	f
223	3	epic	api-test-history-child-1782174581145850947-renamed	History-bearing description.	221	2026-06-23 02:29:41.163332+02	f
221	0	task	api-test-history-parent-a-1782174581134205244	\N	\N	2026-06-23 02:29:41.134363+02	t
223	4	epic	api-test-history-child-1782174581145850947-renamed	History-bearing description.	222	2026-06-23 02:29:41.179948+02	t
222	0	task	api-test-history-parent-b-1782174581139997292	\N	\N	2026-06-23 02:29:41.140121+02	t
224	0	task	api-test-requirement-task-1782174581171548901	\N	\N	2026-06-23 02:29:41.171682+02	t
220	0	task	api-test-requirement-task-1782174581127561570	\N	\N	2026-06-23 02:29:41.127753+02	t
229	0	task	api-test-phase-child-1782174581207975827	\N	225	2026-06-23 02:29:41.214384+02	t
228	0	task	api-test-aggregate-child-1782174581205354018	\N	226	2026-06-23 02:29:41.205608+02	t
226	0	task	api-test-aggregate-parent-1782174581199412918	\N	\N	2026-06-23 02:29:41.199546+02	t
227	0	task	api-test-phase-sibling-1782174581202465263	\N	225	2026-06-23 02:29:41.202748+02	t
225	0	task	api-test-phase-parent-1782174581196610717	\N	\N	2026-06-23 02:29:41.196933+02	t
231	0	task	api-test-child-1782174581248616132	\N	230	2026-06-23 02:29:41.248781+02	f
230	0	task	api-test-parent-1782174581244891741	\N	\N	2026-06-23 02:29:41.24508+02	t
231	1	task	api-test-child-1782174581248616132	\N	\N	2026-06-23 02:29:41.25201+02	t
234	0	task	api-test-counter-child-1782174581268702401	\N	232	2026-06-23 02:29:41.268886+02	f
232	0	task	api-test-counter-parent-a-1782174581262455911	\N	\N	2026-06-23 02:29:41.26258+02	t
234	1	task	api-test-counter-child-1782174581268702401	\N	233	2026-06-23 02:29:41.280019+02	t
233	0	task	api-test-counter-parent-b-1782174581265519287	\N	\N	2026-06-23 02:29:41.265631+02	t
237	0	task	api-test-cycle-grandchild-1782174581298694499	\N	236	2026-06-23 02:29:41.29887+02	t
236	0	task	api-test-cycle-child-1782174581295414651	\N	235	2026-06-23 02:29:41.295586+02	t
235	0	task	api-test-cycle-root-1782174581291957377	\N	\N	2026-06-23 02:29:41.292121+02	t
238	0	task	api-test-task-1782174581312085746	Created by task API integration test.	\N	2026-06-23 02:29:41.312193+02	f
238	1	epic	api-test-task-1782174581312085746-updated	Updated by task API integration test.	\N	2026-06-23 02:29:41.320382+02	t
239	0	task	api-test-parent-task-1782174581343914811	\N	\N	2026-06-23 02:29:41.344039+02	t
240	0	task	api-test-child-task-1782174581346977697	\N	239	2026-06-23 02:29:41.347126+02	t
241	0	task	api-test-requirement-task-1782174826284902213	\N	\N	2026-06-23 02:33:46.285339+02	t
244	0	task	api-test-history-child-1782174826301600820	\N	242	2026-06-23 02:33:46.301891+02	f
245	0	task	api-test-project-delete-task-1782174826308631329	\N	\N	2026-06-23 02:33:46.308836+02	t
244	1	task	api-test-history-child-1782174826301600820-renamed	\N	242	2026-06-23 02:33:46.306109+02	f
244	2	task	api-test-history-child-1782174826301600820-renamed	History-bearing description.	242	2026-06-23 02:33:46.312119+02	f
244	3	epic	api-test-history-child-1782174826301600820-renamed	History-bearing description.	242	2026-06-23 02:33:46.319898+02	f
246	0	task	api-test-requirement-task-1782174826314115332	\N	\N	2026-06-23 02:33:46.314363+02	t
242	0	task	api-test-history-parent-a-1782174826290831611	\N	\N	2026-06-23 02:33:46.290996+02	t
244	4	epic	api-test-history-child-1782174826301600820-renamed	History-bearing description.	243	2026-06-23 02:33:46.344826+02	t
243	0	task	api-test-history-parent-b-1782174826296468935	\N	\N	2026-06-23 02:33:46.296619+02	t
250	0	task	api-test-phase-child-1782174826374108594	\N	248	2026-06-23 02:33:46.380318+02	t
249	0	task	api-test-phase-sibling-1782174826368536103	\N	248	2026-06-23 02:33:46.368886+02	t
248	0	task	api-test-phase-parent-1782174826362342984	\N	\N	2026-06-23 02:33:46.362624+02	t
253	0	task	api-test-child-1782174826407637136	\N	252	2026-06-23 02:33:46.407825+02	f
251	0	task	api-test-requirement-task-1782174826399516888	\N	\N	2026-06-23 02:33:46.399742+02	t
247	0	task	api-test-requirement-task-1782174826353907287	\N	\N	2026-06-23 02:33:46.35406+02	t
252	0	task	api-test-parent-1782174826401924369	\N	\N	2026-06-23 02:33:46.402045+02	t
253	1	task	api-test-child-1782174826407637136	\N	\N	2026-06-23 02:33:46.413072+02	t
256	0	task	api-test-aggregate-child-1782174826432838127	\N	254	2026-06-23 02:33:46.43314+02	t
254	0	task	api-test-aggregate-parent-1782174826427012996	\N	\N	2026-06-23 02:33:46.427138+02	t
258	0	task	api-test-counter-child-1782174826441130743	\N	255	2026-06-23 02:33:46.441381+02	f
257	0	task	api-test-counter-parent-b-1782174826435385514	\N	\N	2026-06-23 02:33:46.435499+02	t
255	0	task	api-test-counter-parent-a-1782174826429919836	\N	\N	2026-06-23 02:33:46.430045+02	t
258	1	task	api-test-counter-child-1782174826441130743	\N	257	2026-06-23 02:33:46.458134+02	t
261	0	task	api-test-cycle-grandchild-1782174826476810790	\N	260	2026-06-23 02:33:46.476944+02	t
260	0	task	api-test-cycle-child-1782174826473466630	\N	259	2026-06-23 02:33:46.473632+02	t
259	0	task	api-test-cycle-root-1782174826470545233	\N	\N	2026-06-23 02:33:46.470646+02	t
262	0	task	api-test-task-1782174826490386617	Created by task API integration test.	\N	2026-06-23 02:33:46.490514+02	f
262	1	epic	api-test-task-1782174826490386617-updated	Updated by task API integration test.	\N	2026-06-23 02:33:46.499266+02	t
263	0	task	api-test-parent-task-1782174826522955377	\N	\N	2026-06-23 02:33:46.523065+02	t
264	0	task	api-test-child-task-1782174826526148260	\N	263	2026-06-23 02:33:46.526272+02	t
265	0	task	api-test-requirement-task-1782175290185000092	\N	\N	2026-06-23 02:41:30.18535+02	t
268	0	task	api-test-history-child-1782175290199822125	\N	266	2026-06-23 02:41:30.200063+02	f
268	1	task	api-test-history-child-1782175290199822125-renamed	\N	266	2026-06-23 02:41:30.206011+02	f
269	0	task	api-test-project-delete-task-1782175290202507384	\N	\N	2026-06-23 02:41:30.202659+02	t
268	2	task	api-test-history-child-1782175290199822125-renamed	History-bearing description.	266	2026-06-23 02:41:30.212419+02	f
268	3	epic	api-test-history-child-1782175290199822125-renamed	History-bearing description.	266	2026-06-23 02:41:30.218064+02	f
270	0	task	api-test-requirement-task-1782175290214529691	\N	\N	2026-06-23 02:41:30.214716+02	t
266	0	task	api-test-history-parent-a-1782175290188076813	\N	\N	2026-06-23 02:41:30.188426+02	t
268	4	epic	api-test-history-child-1782175290199822125-renamed	History-bearing description.	267	2026-06-23 02:41:30.234994+02	t
267	0	task	api-test-history-parent-b-1782175290193974462	\N	\N	2026-06-23 02:41:30.194099+02	t
274	0	task	api-test-phase-child-1782175290264010844	\N	272	2026-06-23 02:41:30.269823+02	t
273	0	task	api-test-phase-sibling-1782175290258117574	\N	272	2026-06-23 02:41:30.258361+02	t
272	0	task	api-test-phase-parent-1782175290252573357	\N	\N	2026-06-23 02:41:30.252819+02	t
277	0	task	api-test-child-1782175290299441848	\N	276	2026-06-23 02:41:30.29964+02	f
275	0	task	api-test-requirement-task-1782175290290240898	\N	\N	2026-06-23 02:41:30.290384+02	t
271	0	task	api-test-requirement-task-1782175290244091732	\N	\N	2026-06-23 02:41:30.24421+02	t
276	0	task	api-test-parent-1782175290293535945	\N	\N	2026-06-23 02:41:30.293662+02	t
277	1	task	api-test-child-1782175290299441848	\N	\N	2026-06-23 02:41:30.306192+02	t
280	0	task	api-test-aggregate-child-1782175290326698242	\N	278	2026-06-23 02:41:30.326948+02	t
278	0	task	api-test-aggregate-parent-1782175290320663794	\N	\N	2026-06-23 02:41:30.320931+02	t
282	0	task	api-test-counter-child-1782175290335460068	\N	279	2026-06-23 02:41:30.335635+02	f
279	0	task	api-test-counter-parent-a-1782175290323576965	\N	\N	2026-06-23 02:41:30.323774+02	t
282	1	task	api-test-counter-child-1782175290335460068	\N	281	2026-06-23 02:41:30.353346+02	t
281	0	task	api-test-counter-parent-b-1782175290329506764	\N	\N	2026-06-23 02:41:30.329639+02	t
285	0	task	api-test-cycle-grandchild-1782175290372116961	\N	284	2026-06-23 02:41:30.372233+02	t
284	0	task	api-test-cycle-child-1782175290368712296	\N	283	2026-06-23 02:41:30.368862+02	t
283	0	task	api-test-cycle-root-1782175290365579538	\N	\N	2026-06-23 02:41:30.365769+02	t
286	0	task	api-test-task-1782175290386177608	Created by task API integration test.	\N	2026-06-23 02:41:30.386294+02	f
286	1	epic	api-test-task-1782175290386177608-updated	Updated by task API integration test.	\N	2026-06-23 02:41:30.394486+02	t
287	0	task	api-test-parent-task-1782175290418601283	\N	\N	2026-06-23 02:41:30.418741+02	t
288	0	task	api-test-child-task-1782175290422010366	\N	287	2026-06-23 02:41:30.422156+02	t
292	0	task	api-test-history-child-1782180420052251886	\N	290	2026-06-23 04:07:00.052523+02	f
292	1	task	api-test-history-child-1782180420052251886-renamed	\N	290	2026-06-23 04:07:00.058089+02	f
293	0	task	api-test-project-delete-task-1782180420055200495	\N	\N	2026-06-23 04:07:00.055383+02	t
292	2	task	api-test-history-child-1782180420052251886-renamed	History-bearing description.	290	2026-06-23 04:07:00.065255+02	f
292	3	epic	api-test-history-child-1782180420052251886-renamed	History-bearing description.	290	2026-06-23 04:07:00.07056+02	f
298	0	task	api-test-phase-child-1782180420107737923	\N	296	2026-06-23 04:07:00.113897+02	t
301	0	task	api-test-child-1782180420135387399	\N	299	2026-06-23 04:07:00.135581+02	f
306	0	task	api-test-counter-child-1782180420163618639	\N	302	2026-06-23 04:07:00.163793+02	f
310	0	task	api-test-task-1782180420205321456	Created by task API integration test.	\N	2026-06-23 04:07:00.205418+02	f
310	1	epic	api-test-task-1782180420205321456-updated	Updated by task API integration test.	\N	2026-06-23 04:07:00.213659+02	t
311	0	task	api-test-parent-task-1782180420237336180	\N	\N	2026-06-23 04:07:00.237458+02	t
312	0	task	api-test-child-task-1782180420240601960	\N	311	2026-06-23 04:07:00.240736+02	t
316	0	task	api-test-history-child-1782182355002635591	\N	314	2026-06-23 04:39:15.002937+02	f
316	1	task	api-test-history-child-1782182355002635591-renamed	\N	314	2026-06-23 04:39:15.00895+02	f
317	0	task	api-test-project-delete-task-1782182355005583418	\N	\N	2026-06-23 04:39:15.005752+02	t
316	2	task	api-test-history-child-1782182355002635591-renamed	History-bearing description.	314	2026-06-23 04:39:15.015198+02	f
316	3	epic	api-test-history-child-1782182355002635591-renamed	History-bearing description.	314	2026-06-23 04:39:15.020692+02	f
322	0	task	api-test-phase-child-1782182355058116171	\N	320	2026-06-23 04:39:15.064725+02	t
325	0	task	api-test-child-1782182355087726793	\N	323	2026-06-23 04:39:15.087962+02	f
330	0	task	api-test-counter-child-1782182355116960850	\N	326	2026-06-23 04:39:15.117187+02	f
334	0	task	api-test-task-1782182355161015546	Created by task API integration test.	\N	2026-06-23 04:39:15.161157+02	f
334	1	epic	api-test-task-1782182355161015546-updated	Updated by task API integration test.	\N	2026-06-23 04:39:15.169397+02	t
335	0	task	api-test-parent-task-1782182355192912248	\N	\N	2026-06-23 04:39:15.193043+02	t
336	0	task	api-test-child-task-1782182355195968231	\N	335	2026-06-23 04:39:15.196134+02	t
340	0	task	api-test-history-child-1782182406711285760	\N	338	2026-06-23 04:40:06.711528+02	f
340	1	task	api-test-history-child-1782182406711285760-renamed	\N	338	2026-06-23 04:40:06.717397+02	f
341	0	task	api-test-project-delete-task-1782182406714134038	\N	\N	2026-06-23 04:40:06.71432+02	t
340	2	task	api-test-history-child-1782182406711285760-renamed	History-bearing description.	338	2026-06-23 04:40:06.723417+02	f
340	3	epic	api-test-history-child-1782182406711285760-renamed	History-bearing description.	338	2026-06-23 04:40:06.729471+02	f
346	0	task	api-test-phase-child-1782182406766503992	\N	344	2026-06-23 04:40:06.772301+02	t
349	0	task	api-test-child-1782182406794771183	\N	347	2026-06-23 04:40:06.794952+02	f
354	0	task	api-test-counter-child-1782182406823911672	\N	350	2026-06-23 04:40:06.824064+02	f
358	0	task	api-test-task-1782182406867415964	Created by task API integration test.	\N	2026-06-23 04:40:06.867505+02	f
358	1	epic	api-test-task-1782182406867415964-updated	Updated by task API integration test.	\N	2026-06-23 04:40:06.874951+02	t
359	0	task	api-test-parent-task-1782182406900695371	\N	\N	2026-06-23 04:40:06.900805+02	t
360	0	task	api-test-child-task-1782182406904296789	\N	359	2026-06-23 04:40:06.904455+02	t
361	0	task	api-test-requirement-task-1782182761060870061	\N	\N	2026-06-23 04:46:01.061334+02	t
363	0	task	api-test-project-delete-task-1782182761079648727	\N	\N	2026-06-23 04:46:01.079847+02	t
365	0	task	api-test-history-child-1782182761088164235	\N	362	2026-06-23 04:46:01.088473+02	f
365	1	task	api-test-history-child-1782182761088164235-renamed	\N	362	2026-06-23 04:46:01.094284+02	f
365	2	task	api-test-history-child-1782182761088164235-renamed	History-bearing description.	362	2026-06-23 04:46:01.100704+02	f
365	3	epic	api-test-history-child-1782182761088164235-renamed	History-bearing description.	362	2026-06-23 04:46:01.107209+02	f
366	0	task	api-test-requirement-task-1782182761099505939	\N	\N	2026-06-23 04:46:01.099768+02	t
362	0	task	api-test-history-parent-a-1782182761077060192	\N	\N	2026-06-23 04:46:01.077249+02	t
364	0	task	api-test-history-parent-b-1782182761082582206	\N	\N	2026-06-23 04:46:01.082768+02	t
365	4	epic	api-test-history-child-1782182761088164235-renamed	History-bearing description.	364	2026-06-23 04:46:01.123057+02	t
370	0	task	api-test-phase-child-1782182761162650522	\N	368	2026-06-23 04:46:01.168963+02	t
368	0	task	api-test-phase-parent-1782182761151402575	\N	\N	2026-06-23 04:46:01.151727+02	t
369	0	task	api-test-phase-sibling-1782182761156835541	\N	368	2026-06-23 04:46:01.157265+02	t
367	0	task	api-test-requirement-task-1782182761131756614	\N	\N	2026-06-23 04:46:01.132016+02	t
371	0	task	api-test-requirement-task-1782182761177077584	\N	\N	2026-06-23 04:46:01.177259+02	t
373	0	task	api-test-child-1782182761208546394	\N	372	2026-06-23 04:46:01.208886+02	f
372	0	task	api-test-parent-1782182761203040099	\N	\N	2026-06-23 04:46:01.203223+02	t
373	1	task	api-test-child-1782182761208546394	\N	\N	2026-06-23 04:46:01.214389+02	t
374	0	task	api-test-aggregate-parent-1782182761223331456	\N	\N	2026-06-23 04:46:01.223722+02	t
375	0	task	api-test-aggregate-child-1782182761229793857	\N	374	2026-06-23 04:46:01.230157+02	t
378	0	task	api-test-counter-child-1782182761257251540	\N	376	2026-06-23 04:46:01.257639+02	f
376	0	task	api-test-counter-parent-a-1782182761243947450	\N	\N	2026-06-23 04:46:01.24412+02	t
377	0	task	api-test-counter-parent-b-1782182761249791927	\N	\N	2026-06-23 04:46:01.249989+02	t
378	1	task	api-test-counter-child-1782182761257251540	\N	377	2026-06-23 04:46:01.270532+02	t
379	0	task	api-test-cycle-root-1782182761292243570	\N	\N	2026-06-23 04:46:01.292455+02	t
380	0	task	api-test-cycle-child-1782182761296210401	\N	379	2026-06-23 04:46:01.296471+02	t
381	0	task	api-test-cycle-grandchild-1782182761300326627	\N	380	2026-06-23 04:46:01.300576+02	t
382	0	task	api-test-task-1782182761321450765	Created by task API integration test.	\N	2026-06-23 04:46:01.321633+02	f
382	1	epic	api-test-task-1782182761321450765-updated	Updated by task API integration test.	\N	2026-06-23 04:46:01.329573+02	t
383	0	task	api-test-parent-task-1782182761356663724	\N	\N	2026-06-23 04:46:01.356829+02	t
384	0	task	api-test-child-task-1782182761359868098	\N	383	2026-06-23 04:46:01.360064+02	t
385	0	task	api-test-requirement-task-1782183769489648084	\N	\N	2026-06-23 05:02:49.489906+02	t
388	0	task	api-test-history-child-1782183769503772101	\N	386	2026-06-23 05:02:49.504067+02	f
388	1	task	api-test-history-child-1782183769503772101-renamed	\N	386	2026-06-23 05:02:49.509262+02	f
388	2	task	api-test-history-child-1782183769503772101-renamed	History-bearing description.	386	2026-06-23 05:02:49.516225+02	f
389	0	task	api-test-project-delete-task-1782183769512098189	\N	\N	2026-06-23 05:02:49.512272+02	t
388	3	epic	api-test-history-child-1782183769503772101-renamed	History-bearing description.	386	2026-06-23 05:02:49.521376+02	f
390	0	task	api-test-requirement-task-1782183769523953669	\N	\N	2026-06-23 05:02:49.524144+02	t
386	0	task	api-test-history-parent-a-1782183769492104307	\N	\N	2026-06-23 05:02:49.492317+02	t
387	0	task	api-test-history-parent-b-1782183769498053924	\N	\N	2026-06-23 05:02:49.49825+02	t
388	4	epic	api-test-history-child-1782183769503772101-renamed	History-bearing description.	387	2026-06-23 05:02:49.538205+02	t
394	0	task	api-test-phase-child-1782183769578830653	\N	392	2026-06-23 05:02:49.584943+02	t
392	0	task	api-test-phase-parent-1782183769567634164	\N	\N	2026-06-23 05:02:49.567907+02	t
393	0	task	api-test-phase-sibling-1782183769572920090	\N	392	2026-06-23 05:02:49.573366+02	t
391	0	task	api-test-requirement-task-1782183769558905190	\N	\N	2026-06-23 05:02:49.559067+02	t
395	0	task	api-test-requirement-task-1782183769604415399	\N	\N	2026-06-23 05:02:49.604649+02	t
398	0	task	api-test-aggregate-parent-1782183769644846786	\N	\N	2026-06-23 05:02:49.645054+02	t
399	0	task	api-test-aggregate-child-1782183769649702665	\N	398	2026-06-23 05:02:49.649996+02	t
397	0	task	api-test-child-1782183769618574583	\N	396	2026-06-23 05:02:49.61893+02	f
396	0	task	api-test-parent-1782183769613172607	\N	\N	2026-06-23 05:02:49.613339+02	t
397	1	task	api-test-child-1782183769618574583	\N	\N	2026-06-23 05:02:49.624269+02	t
402	0	task	api-test-counter-child-1782183769664709849	\N	400	2026-06-23 05:02:49.664944+02	f
400	0	task	api-test-counter-parent-a-1782183769652931025	\N	\N	2026-06-23 05:02:49.653117+02	t
401	0	task	api-test-counter-parent-b-1782183769659017661	\N	\N	2026-06-23 05:02:49.659208+02	t
402	1	task	api-test-counter-child-1782183769664709849	\N	401	2026-06-23 05:02:49.682187+02	t
403	0	task	api-test-cycle-root-1782183769703264261	\N	\N	2026-06-23 05:02:49.703398+02	t
404	0	task	api-test-cycle-child-1782183769706485507	\N	403	2026-06-23 05:02:49.70673+02	t
405	0	task	api-test-cycle-grandchild-1782183769709726802	\N	404	2026-06-23 05:02:49.709937+02	t
406	0	task	api-test-task-1782183769729936884	Created by task API integration test.	\N	2026-06-23 05:02:49.730086+02	f
406	1	epic	api-test-task-1782183769729936884-updated	Updated by task API integration test.	\N	2026-06-23 05:02:49.739669+02	t
407	0	task	api-test-parent-task-1782183769767159277	\N	\N	2026-06-23 05:02:49.767313+02	t
408	0	task	api-test-child-task-1782183769770764943	\N	407	2026-06-23 05:02:49.771018+02	t
409	0	task	api-test-requirement-task-1782183808532074339	\N	\N	2026-06-23 05:03:28.53242+02	t
412	0	task	api-test-history-child-1782183808554207523	\N	410	2026-06-23 05:03:28.554615+02	f
412	1	task	api-test-history-child-1782183808554207523-renamed	\N	410	2026-06-23 05:03:28.560455+02	f
413	0	task	api-test-project-delete-task-1782183808560179081	\N	\N	2026-06-23 05:03:28.560424+02	t
412	2	task	api-test-history-child-1782183808554207523-renamed	History-bearing description.	410	2026-06-23 05:03:28.566691+02	f
412	3	epic	api-test-history-child-1782183808554207523-renamed	History-bearing description.	410	2026-06-23 05:03:28.580177+02	f
414	0	task	api-test-requirement-task-1782183808568796032	\N	\N	2026-06-23 05:03:28.569028+02	t
410	0	task	api-test-history-parent-a-1782183808542282581	\N	\N	2026-06-23 05:03:28.54258+02	t
411	0	task	api-test-history-parent-b-1782183808550139288	\N	\N	2026-06-23 05:03:28.550383+02	t
412	4	epic	api-test-history-child-1782183808554207523-renamed	History-bearing description.	411	2026-06-23 05:03:28.5983+02	t
418	0	task	api-test-phase-child-1782183808637556806	\N	416	2026-06-23 05:03:28.643878+02	t
416	0	task	api-test-phase-parent-1782183808625989644	\N	\N	2026-06-23 05:03:28.626313+02	t
417	0	task	api-test-phase-sibling-1782183808631841054	\N	416	2026-06-23 05:03:28.632373+02	t
415	0	task	api-test-requirement-task-1782183808617597670	\N	\N	2026-06-23 05:03:28.617779+02	t
421	0	task	api-test-child-1782183808678000666	\N	420	2026-06-23 05:03:28.678292+02	f
419	0	task	api-test-requirement-task-1782183808664194452	\N	\N	2026-06-23 05:03:28.664395+02	t
420	0	task	api-test-parent-1782183808672571337	\N	\N	2026-06-23 05:03:28.672819+02	t
421	1	task	api-test-child-1782183808678000666	\N	\N	2026-06-23 05:03:28.68417+02	t
422	0	task	api-test-aggregate-parent-1782183808704229676	\N	\N	2026-06-23 05:03:28.704358+02	t
423	0	task	api-test-aggregate-child-1782183808709926342	\N	422	2026-06-23 05:03:28.710283+02	t
426	0	task	api-test-counter-child-1782183808724732835	\N	424	2026-06-23 05:03:28.725036+02	f
424	0	task	api-test-counter-parent-a-1782183808712923382	\N	\N	2026-06-23 05:03:28.713052+02	t
425	0	task	api-test-counter-parent-b-1782183808718998427	\N	\N	2026-06-23 05:03:28.719195+02	t
426	1	task	api-test-counter-child-1782183808724732835	\N	425	2026-06-23 05:03:28.742131+02	t
427	0	task	api-test-cycle-root-1782183808763623335	\N	\N	2026-06-23 05:03:28.763774+02	t
428	0	task	api-test-cycle-child-1782183808767021026	\N	427	2026-06-23 05:03:28.767216+02	t
429	0	task	api-test-cycle-grandchild-1782183808770147783	\N	428	2026-06-23 05:03:28.770298+02	t
430	0	task	api-test-task-1782183808789360301	Created by task API integration test.	\N	2026-06-23 05:03:28.789502+02	f
430	1	epic	api-test-task-1782183808789360301-updated	Updated by task API integration test.	\N	2026-06-23 05:03:28.798185+02	t
431	0	task	api-test-parent-task-1782183808823146981	\N	\N	2026-06-23 05:03:28.823357+02	t
432	0	task	api-test-child-task-1782183808827443148	\N	431	2026-06-23 05:03:28.827742+02	t
433	0	task	api-test-requirement-task-1782210199529758894	\N	\N	2026-06-23 12:23:19.529998+02	t
436	0	task	api-test-history-child-1782210199545091016	\N	434	2026-06-23 12:23:19.545374+02	f
436	1	task	api-test-history-child-1782210199545091016-renamed	\N	434	2026-06-23 12:23:19.550975+02	f
437	0	task	api-test-project-delete-task-1782210199547858229	\N	\N	2026-06-23 12:23:19.547977+02	t
436	2	task	api-test-history-child-1782210199545091016-renamed	History-bearing description.	434	2026-06-23 12:23:19.557632+02	f
436	3	epic	api-test-history-child-1782210199545091016-renamed	History-bearing description.	434	2026-06-23 12:23:19.56311+02	f
438	0	task	api-test-requirement-task-1782210199565858496	\N	\N	2026-06-23 12:23:19.565983+02	t
434	0	task	api-test-history-parent-a-1782210199536262609	\N	\N	2026-06-23 12:23:19.536442+02	t
435	0	task	api-test-history-parent-b-1782210199541677136	\N	\N	2026-06-23 12:23:19.541826+02	t
436	4	epic	api-test-history-child-1782210199545091016-renamed	History-bearing description.	435	2026-06-23 12:23:19.580892+02	t
442	0	task	api-test-phase-child-1782210199622722232	\N	440	2026-06-23 12:23:19.629464+02	t
440	0	task	api-test-phase-parent-1782210199611053233	\N	\N	2026-06-23 12:23:19.611292+02	t
441	0	task	api-test-phase-sibling-1782210199617232832	\N	440	2026-06-23 12:23:19.617524+02	t
439	0	task	api-test-requirement-task-1782210199602508614	\N	\N	2026-06-23 12:23:19.602691+02	t
445	0	task	api-test-child-1782210199664122396	\N	444	2026-06-23 12:23:19.664288+02	f
443	0	task	api-test-requirement-task-1782210199650141869	\N	\N	2026-06-23 12:23:19.650304+02	t
444	0	task	api-test-parent-1782210199658865157	\N	\N	2026-06-23 12:23:19.658983+02	t
445	1	task	api-test-child-1782210199664122396	\N	\N	2026-06-23 12:23:19.670505+02	t
446	0	task	api-test-aggregate-parent-1782210199690274146	\N	\N	2026-06-23 12:23:19.690402+02	t
447	0	task	api-test-aggregate-child-1782210199695550962	\N	446	2026-06-23 12:23:19.69573+02	t
450	0	task	api-test-counter-child-1782210199710424855	\N	448	2026-06-23 12:23:19.710593+02	f
448	0	task	api-test-counter-parent-a-1782210199698944884	\N	\N	2026-06-23 12:23:19.699065+02	t
449	0	task	api-test-counter-parent-b-1782210199704361596	\N	\N	2026-06-23 12:23:19.704467+02	t
450	1	task	api-test-counter-child-1782210199710424855	\N	449	2026-06-23 12:23:19.727574+02	t
451	0	task	api-test-cycle-root-1782210199746676285	\N	\N	2026-06-23 12:23:19.746762+02	t
452	0	task	api-test-cycle-child-1782210199749820083	\N	451	2026-06-23 12:23:19.749981+02	t
453	0	task	api-test-cycle-grandchild-1782210199752892916	\N	452	2026-06-23 12:23:19.753038+02	t
454	0	task	api-test-task-1782210199771291940	Created by task API integration test.	\N	2026-06-23 12:23:19.771389+02	f
454	1	epic	api-test-task-1782210199771291940-updated	Updated by task API integration test.	\N	2026-06-23 12:23:19.779161+02	t
455	0	task	api-test-parent-task-1782210199801872556	\N	\N	2026-06-23 12:23:19.801971+02	t
456	0	task	api-test-child-task-1782210199805188781	\N	455	2026-06-23 12:23:19.805346+02	t
457	0	task	api-test-requirement-task-1782210397982209813	\N	\N	2026-06-23 12:26:37.98243+02	t
460	0	task	api-test-history-child-1782210397996932599	\N	458	2026-06-23 12:26:37.997201+02	f
460	1	task	api-test-history-child-1782210397996932599-renamed	\N	458	2026-06-23 12:26:38.003044+02	f
461	0	task	api-test-project-delete-task-1782210398000093570	\N	\N	2026-06-23 12:26:38.000223+02	t
460	2	task	api-test-history-child-1782210397996932599-renamed	History-bearing description.	458	2026-06-23 12:26:38.009646+02	f
460	3	epic	api-test-history-child-1782210397996932599-renamed	History-bearing description.	458	2026-06-23 12:26:38.015403+02	f
462	0	task	api-test-requirement-task-1782210398017421972	\N	\N	2026-06-23 12:26:38.017556+02	t
458	0	task	api-test-history-parent-a-1782210397987930492	\N	\N	2026-06-23 12:26:37.988142+02	t
459	0	task	api-test-history-parent-b-1782210397993072482	\N	\N	2026-06-23 12:26:37.99329+02	t
460	4	epic	api-test-history-child-1782210397996932599-renamed	History-bearing description.	459	2026-06-23 12:26:38.03208+02	t
466	0	task	api-test-phase-child-1782210398072844295	\N	464	2026-06-23 12:26:38.078808+02	t
464	0	task	api-test-phase-parent-1782210398061995652	\N	\N	2026-06-23 12:26:38.062292+02	t
465	0	task	api-test-phase-sibling-1782210398067305652	\N	464	2026-06-23 12:26:38.067598+02	t
463	0	task	api-test-requirement-task-1782210398053319854	\N	\N	2026-06-23 12:26:38.053478+02	t
469	0	task	api-test-child-1782210398115218089	\N	468	2026-06-23 12:26:38.115455+02	f
467	0	task	api-test-requirement-task-1782210398100232544	\N	\N	2026-06-23 12:26:38.100382+02	t
468	0	task	api-test-parent-1782210398109042817	\N	\N	2026-06-23 12:26:38.109179+02	t
469	1	task	api-test-child-1782210398115218089	\N	\N	2026-06-23 12:26:38.121248+02	t
470	0	task	api-test-aggregate-parent-1782210398142745682	\N	\N	2026-06-23 12:26:38.142946+02	t
471	0	task	api-test-aggregate-child-1782210398149068995	\N	470	2026-06-23 12:26:38.149269+02	t
474	0	task	api-test-counter-child-1782210398164811097	\N	472	2026-06-23 12:26:38.165011+02	f
472	0	task	api-test-counter-parent-a-1782210398152031559	\N	\N	2026-06-23 12:26:38.152129+02	t
473	0	task	api-test-counter-parent-b-1782210398158198034	\N	\N	2026-06-23 12:26:38.158337+02	t
474	1	task	api-test-counter-child-1782210398164811097	\N	473	2026-06-23 12:26:38.183798+02	t
475	0	task	api-test-cycle-root-1782210398204408400	\N	\N	2026-06-23 12:26:38.204513+02	t
476	0	task	api-test-cycle-child-1782210398208123853	\N	475	2026-06-23 12:26:38.208337+02	t
477	0	task	api-test-cycle-grandchild-1782210398211592738	\N	476	2026-06-23 12:26:38.211886+02	t
478	0	task	api-test-task-1782210398231302330	Created by task API integration test.	\N	2026-06-23 12:26:38.231401+02	f
478	1	epic	api-test-task-1782210398231302330-updated	Updated by task API integration test.	\N	2026-06-23 12:26:38.23915+02	t
479	0	task	api-test-parent-task-1782210398264741014	\N	\N	2026-06-23 12:26:38.264868+02	t
480	0	task	api-test-child-task-1782210398267820058	\N	479	2026-06-23 12:26:38.267962+02	t
481	0	task	api-test-requirement-task-1782211254434257409	\N	\N	2026-06-23 12:40:54.434495+02	t
485	0	task	api-test-history-child-1782211254454833206	\N	482	2026-06-23 12:40:54.455108+02	f
484	0	task	api-test-project-delete-task-1782211254451844744	\N	\N	2026-06-23 12:40:54.452017+02	t
485	1	task	api-test-history-child-1782211254454833206-renamed	\N	482	2026-06-23 12:40:54.46026+02	f
485	2	task	api-test-history-child-1782211254454833206-renamed	History-bearing description.	482	2026-06-23 12:40:54.467059+02	f
485	3	epic	api-test-history-child-1782211254454833206-renamed	History-bearing description.	482	2026-06-23 12:40:54.471864+02	f
486	0	task	api-test-requirement-task-1782211254468946396	\N	\N	2026-06-23 12:40:54.469085+02	t
482	0	task	api-test-history-parent-a-1782211254445610881	\N	\N	2026-06-23 12:40:54.445807+02	t
483	0	task	api-test-history-parent-b-1782211254448897038	\N	\N	2026-06-23 12:40:54.449043+02	t
485	4	epic	api-test-history-child-1782211254454833206-renamed	History-bearing description.	483	2026-06-23 12:40:54.489317+02	t
490	0	task	api-test-phase-child-1782211254528552621	\N	488	2026-06-23 12:40:54.535263+02	t
488	0	task	api-test-phase-parent-1782211254517502575	\N	\N	2026-06-23 12:40:54.517804+02	t
489	0	task	api-test-phase-sibling-1782211254523316251	\N	488	2026-06-23 12:40:54.523531+02	t
487	0	task	api-test-requirement-task-1782211254503537236	\N	\N	2026-06-23 12:40:54.50366+02	t
491	0	task	api-test-requirement-task-1782211254548786108	\N	\N	2026-06-23 12:40:54.54895+02	t
493	0	task	api-test-child-1782211254568537380	\N	492	2026-06-23 12:40:54.56874+02	f
492	0	task	api-test-parent-1782211254562824165	\N	\N	2026-06-23 12:40:54.562953+02	t
493	1	task	api-test-child-1782211254568537380	\N	\N	2026-06-23 12:40:54.574461+02	t
494	0	task	api-test-aggregate-parent-1782211254588529288	\N	\N	2026-06-23 12:40:54.588693+02	t
495	0	task	api-test-aggregate-child-1782211254594368983	\N	494	2026-06-23 12:40:54.594719+02	t
498	0	task	api-test-counter-child-1782211254613950082	\N	496	2026-06-23 12:40:54.614225+02	f
496	0	task	api-test-counter-parent-a-1782211254602736306	\N	\N	2026-06-23 12:40:54.602904+02	t
497	0	task	api-test-counter-parent-b-1782211254608232870	\N	\N	2026-06-23 12:40:54.608391+02	t
498	1	task	api-test-counter-child-1782211254613950082	\N	497	2026-06-23 12:40:54.630196+02	t
499	0	task	api-test-cycle-root-1782211254650852941	\N	\N	2026-06-23 12:40:54.65096+02	t
500	0	task	api-test-cycle-child-1782211254654343036	\N	499	2026-06-23 12:40:54.654489+02	t
501	0	task	api-test-cycle-grandchild-1782211254658068488	\N	500	2026-06-23 12:40:54.658288+02	t
502	0	task	api-test-task-1782211254678253984	Created by task API integration test.	\N	2026-06-23 12:40:54.67841+02	f
502	1	epic	api-test-task-1782211254678253984-updated	Updated by task API integration test.	\N	2026-06-23 12:40:54.686092+02	t
503	0	task	api-test-parent-task-1782211254712412804	\N	\N	2026-06-23 12:40:54.712555+02	t
504	0	task	api-test-child-task-1782211254715628709	\N	503	2026-06-23 12:40:54.715811+02	t
505	0	task	api-test-requirement-task-1782211342099550692	\N	\N	2026-06-23 12:42:22.100151+02	t
508	0	task	api-test-history-child-1782211342116977562	\N	506	2026-06-23 12:42:22.117211+02	f
508	1	task	api-test-history-child-1782211342116977562-renamed	\N	506	2026-06-23 12:42:22.120524+02	f
509	0	task	api-test-project-delete-task-1782211342123506826	\N	\N	2026-06-23 12:42:22.1237+02	t
508	2	task	api-test-history-child-1782211342116977562-renamed	History-bearing description.	506	2026-06-23 12:42:22.127251+02	f
508	3	epic	api-test-history-child-1782211342116977562-renamed	History-bearing description.	506	2026-06-23 12:42:22.132153+02	f
506	0	task	api-test-history-parent-a-1782211342105901127	\N	\N	2026-06-23 12:42:22.10612+02	t
507	0	task	api-test-history-parent-b-1782211342110727208	\N	\N	2026-06-23 12:42:22.110866+02	t
508	4	epic	api-test-history-child-1782211342116977562-renamed	History-bearing description.	507	2026-06-23 12:42:22.149944+02	t
514	0	task	api-test-phase-child-1782211342191320704	\N	512	2026-06-23 12:42:22.197887+02	t
512	0	task	api-test-phase-parent-1782211342179750571	\N	\N	2026-06-23 12:42:22.180065+02	t
513	0	task	api-test-phase-sibling-1782211342185707358	\N	512	2026-06-23 12:42:22.185968+02	t
517	0	task	api-test-child-1782211342232889721	\N	516	2026-06-23 12:42:22.233079+02	f
516	0	task	api-test-parent-1782211342226868933	\N	\N	2026-06-23 12:42:22.227016+02	t
517	1	task	api-test-child-1782211342232889721	\N	\N	2026-06-23 12:42:22.23853+02	t
522	0	task	api-test-counter-child-1782211342279541648	\N	520	2026-06-23 12:42:22.279751+02	f
520	0	task	api-test-counter-parent-a-1782211342267619427	\N	\N	2026-06-23 12:42:22.26773+02	t
521	0	task	api-test-counter-parent-b-1782211342274007693	\N	\N	2026-06-23 12:42:22.27415+02	t
522	1	task	api-test-counter-child-1782211342279541648	\N	521	2026-06-23 12:42:22.297544+02	t
523	0	task	api-test-cycle-root-1782211342317307226	\N	\N	2026-06-23 12:42:22.3174+02	t
524	0	task	api-test-cycle-child-1782211342321039201	\N	523	2026-06-23 12:42:22.321225+02	t
525	0	task	api-test-cycle-grandchild-1782211342324198788	\N	524	2026-06-23 12:42:22.324346+02	t
526	0	task	api-test-task-1782211342342600419	Created by task API integration test.	\N	2026-06-23 12:42:22.342704+02	f
526	1	epic	api-test-task-1782211342342600419-updated	Updated by task API integration test.	\N	2026-06-23 12:42:22.350872+02	t
527	0	task	api-test-parent-task-1782211342374835168	\N	\N	2026-06-23 12:42:22.374954+02	t
528	0	task	api-test-child-task-1782211342378153167	\N	527	2026-06-23 12:42:22.378292+02	t
510	0	task	api-test-requirement-task-1782211342134966369	\N	\N	2026-06-23 12:42:22.135103+02	t
511	0	task	api-test-requirement-task-1782211342171068009	\N	\N	2026-06-23 12:42:22.17123+02	t
515	0	task	api-test-requirement-task-1782211342218241636	\N	\N	2026-06-23 12:42:22.218406+02	t
518	0	task	api-test-aggregate-parent-1782211342258835182	\N	\N	2026-06-23 12:42:22.25903+02	t
519	0	task	api-test-aggregate-child-1782211342264847144	\N	518	2026-06-23 12:42:22.265162+02	t
533	0	task	api-test-history-child-1782309745308422050	\N	530	2026-06-24 16:02:25.308744+02	f
529	0	task	api-test-requirement-task-1782309745285609084	\N	\N	2026-06-24 16:02:25.285832+02	t
532	0	task	api-test-project-delete-task-1782309745305645018	\N	\N	2026-06-24 16:02:25.305758+02	t
533	1	task	api-test-history-child-1782309745308422050-renamed	\N	530	2026-06-24 16:02:25.317161+02	f
533	2	task	api-test-history-child-1782309745308422050-renamed	History-bearing description.	530	2026-06-24 16:02:25.324882+02	f
533	3	epic	api-test-history-child-1782309745308422050-renamed	History-bearing description.	530	2026-06-24 16:02:25.331426+02	f
534	0	task	api-test-requirement-task-1782309745333360400	\N	\N	2026-06-24 16:02:25.333513+02	t
530	0	task	api-test-history-parent-a-1782309745285611048	\N	\N	2026-06-24 16:02:25.285834+02	t
531	0	task	api-test-history-parent-b-1782309745302288476	\N	\N	2026-06-24 16:02:25.302457+02	t
533	4	epic	api-test-history-child-1782309745308422050-renamed	History-bearing description.	531	2026-06-24 16:02:25.347878+02	t
538	0	task	api-test-phase-child-1782309745388429326	\N	536	2026-06-24 16:02:25.393899+02	t
536	0	task	api-test-phase-parent-1782309745376825188	\N	\N	2026-06-24 16:02:25.377097+02	t
537	0	task	api-test-phase-sibling-1782309745381777008	\N	536	2026-06-24 16:02:25.382132+02	t
535	0	task	api-test-requirement-task-1782309745367782112	\N	\N	2026-06-24 16:02:25.367901+02	t
541	0	task	api-test-child-1782309745429117193	\N	540	2026-06-24 16:02:25.429303+02	f
539	0	task	api-test-requirement-task-1782309745414265601	\N	\N	2026-06-24 16:02:25.41438+02	t
540	0	task	api-test-parent-1782309745423358271	\N	\N	2026-06-24 16:02:25.42347+02	t
541	1	task	api-test-child-1782309745429117193	\N	\N	2026-06-24 16:02:25.4346+02	t
542	0	task	api-test-aggregate-parent-1782309745454779638	\N	\N	2026-06-24 16:02:25.454892+02	t
543	0	task	api-test-aggregate-child-1782309745460873746	\N	542	2026-06-24 16:02:25.461145+02	t
546	0	task	api-test-counter-child-1782309745475376216	\N	544	2026-06-24 16:02:25.475579+02	f
544	0	task	api-test-counter-parent-a-1782309745464082167	\N	\N	2026-06-24 16:02:25.464192+02	t
545	0	task	api-test-counter-parent-b-1782309745469564995	\N	\N	2026-06-24 16:02:25.469674+02	t
546	1	task	api-test-counter-child-1782309745475376216	\N	545	2026-06-24 16:02:25.493564+02	t
547	0	task	api-test-cycle-root-1782309745512757857	\N	\N	2026-06-24 16:02:25.512895+02	t
548	0	task	api-test-cycle-child-1782309745516088019	\N	547	2026-06-24 16:02:25.51625+02	t
549	0	task	api-test-cycle-grandchild-1782309745519746614	\N	548	2026-06-24 16:02:25.51987+02	t
550	0	task	api-test-task-1782309745538138376	Created by task API integration test.	\N	2026-06-24 16:02:25.538233+02	f
550	1	epic	api-test-task-1782309745538138376-updated	Updated by task API integration test.	\N	2026-06-24 16:02:25.547505+02	t
551	0	task	api-test-parent-task-1782309745571998643	\N	\N	2026-06-24 16:02:25.572088+02	t
552	0	task	api-test-child-task-1782309745575358851	\N	551	2026-06-24 16:02:25.575546+02	t
553	0	task	api-test-requirement-task-1782309798767332733	\N	\N	2026-06-24 16:03:18.767569+02	t
557	0	task	api-test-history-child-1782309798781019173	\N	554	2026-06-24 16:03:18.781318+02	f
555	0	task	api-test-project-delete-task-1782309798775753127	\N	\N	2026-06-24 16:03:18.775947+02	t
557	1	task	api-test-history-child-1782309798781019173-renamed	\N	554	2026-06-24 16:03:18.786805+02	f
557	2	task	api-test-history-child-1782309798781019173-renamed	History-bearing description.	554	2026-06-24 16:03:18.793177+02	f
557	3	epic	api-test-history-child-1782309798781019173-renamed	History-bearing description.	554	2026-06-24 16:03:18.79869+02	f
558	0	task	api-test-requirement-task-1782309798800568413	\N	\N	2026-06-24 16:03:18.800753+02	t
554	0	task	api-test-history-parent-a-1782309798769414885	\N	\N	2026-06-24 16:03:18.769647+02	t
556	0	task	api-test-history-parent-b-1782309798775615916	\N	\N	2026-06-24 16:03:18.775779+02	t
557	4	epic	api-test-history-child-1782309798781019173-renamed	History-bearing description.	556	2026-06-24 16:03:18.814926+02	t
562	0	task	api-test-phase-child-1782309798855267087	\N	560	2026-06-24 16:03:18.861759+02	t
560	0	task	api-test-phase-parent-1782309798844288787	\N	\N	2026-06-24 16:03:18.844621+02	t
561	0	task	api-test-phase-sibling-1782309798849852609	\N	560	2026-06-24 16:03:18.850169+02	t
559	0	task	api-test-requirement-task-1782309798835561911	\N	\N	2026-06-24 16:03:18.835708+02	t
565	0	task	api-test-child-1782309798895088570	\N	564	2026-06-24 16:03:18.895347+02	f
563	0	task	api-test-requirement-task-1782309798881006237	\N	\N	2026-06-24 16:03:18.881182+02	t
564	0	task	api-test-parent-1782309798889701644	\N	\N	2026-06-24 16:03:18.889868+02	t
565	1	task	api-test-child-1782309798895088570	\N	\N	2026-06-24 16:03:18.900892+02	t
566	0	task	api-test-aggregate-parent-1782309798922385928	\N	\N	2026-06-24 16:03:18.922647+02	t
567	0	task	api-test-aggregate-child-1782309798927723720	\N	566	2026-06-24 16:03:18.928196+02	t
570	0	task	api-test-counter-child-1782309798941662951	\N	568	2026-06-24 16:03:18.941969+02	f
568	0	task	api-test-counter-parent-a-1782309798930745947	\N	\N	2026-06-24 16:03:18.930883+02	t
569	0	task	api-test-counter-parent-b-1782309798935767329	\N	\N	2026-06-24 16:03:18.935912+02	t
570	1	task	api-test-counter-child-1782309798941662951	\N	569	2026-06-24 16:03:18.958783+02	t
571	0	task	api-test-cycle-root-1782309798982985513	\N	\N	2026-06-24 16:03:18.983166+02	t
572	0	task	api-test-cycle-child-1782309798986360710	\N	571	2026-06-24 16:03:18.986632+02	t
573	0	task	api-test-cycle-grandchild-1782309798990844181	\N	572	2026-06-24 16:03:18.99126+02	t
574	0	task	api-test-task-1782309799014287012	Created by task API integration test.	\N	2026-06-24 16:03:19.014501+02	f
574	1	epic	api-test-task-1782309799014287012-updated	Updated by task API integration test.	\N	2026-06-24 16:03:19.025562+02	t
575	0	task	api-test-parent-task-1782309799054057467	\N	\N	2026-06-24 16:03:19.054179+02	t
576	0	task	api-test-child-task-1782309799057827865	\N	575	2026-06-24 16:03:19.058108+02	t
577	0	task	api-test-requirement-task-1782310831066728529	\N	\N	2026-06-24 16:20:31.06693+02	t
580	0	task	api-test-history-child-1782310831080074393	\N	578	2026-06-24 16:20:31.080364+02	f
580	1	task	api-test-history-child-1782310831080074393-renamed	\N	578	2026-06-24 16:20:31.089091+02	f
581	0	task	api-test-project-delete-task-1782310831086096004	\N	\N	2026-06-24 16:20:31.086257+02	t
580	2	task	api-test-history-child-1782310831080074393-renamed	History-bearing description.	578	2026-06-24 16:20:31.09536+02	f
578	0	task	api-test-history-parent-a-1782310831069159584	\N	\N	2026-06-24 16:20:31.069308+02	t
579	0	task	api-test-history-parent-b-1782310831074836731	\N	\N	2026-06-24 16:20:31.074967+02	t
580	4	epic	api-test-history-child-1782310831080074393-renamed	History-bearing description.	579	2026-06-24 16:20:31.117863+02	t
586	0	task	api-test-phase-child-1782310831159515034	\N	584	2026-06-24 16:20:31.165812+02	t
584	0	task	api-test-phase-parent-1782310831148023209	\N	\N	2026-06-24 16:20:31.148313+02	t
585	0	task	api-test-phase-sibling-1782310831153648748	\N	584	2026-06-24 16:20:31.154143+02	t
589	0	task	api-test-child-1782310831200473464	\N	588	2026-06-24 16:20:31.200663+02	f
588	0	task	api-test-parent-1782310831194767072	\N	\N	2026-06-24 16:20:31.194889+02	t
589	1	task	api-test-child-1782310831200473464	\N	\N	2026-06-24 16:20:31.206431+02	t
594	0	task	api-test-counter-child-1782310831247322237	\N	592	2026-06-24 16:20:31.247531+02	f
592	0	task	api-test-counter-parent-a-1782310831235491469	\N	\N	2026-06-24 16:20:31.235596+02	t
593	0	task	api-test-counter-parent-b-1782310831241293873	\N	\N	2026-06-24 16:20:31.241431+02	t
594	1	task	api-test-counter-child-1782310831247322237	\N	593	2026-06-24 16:20:31.264805+02	t
595	0	task	api-test-cycle-root-1782310831284789330	\N	\N	2026-06-24 16:20:31.284901+02	t
596	0	task	api-test-cycle-child-1782310831287805275	\N	595	2026-06-24 16:20:31.287936+02	t
597	0	task	api-test-cycle-grandchild-1782310831291071696	\N	596	2026-06-24 16:20:31.29119+02	t
598	0	task	api-test-task-1782310831309709706	Created by task API integration test.	\N	2026-06-24 16:20:31.309819+02	f
598	1	epic	api-test-task-1782310831309709706-updated	Updated by task API integration test.	\N	2026-06-24 16:20:31.317938+02	t
599	0	task	api-test-parent-task-1782310831343103677	\N	\N	2026-06-24 16:20:31.343201+02	t
600	0	task	api-test-child-task-1782310831346095085	\N	599	2026-06-24 16:20:31.346231+02	t
580	3	epic	api-test-history-child-1782310831080074393-renamed	History-bearing description.	578	2026-06-24 16:20:31.100941+02	f
582	0	task	api-test-requirement-task-1782310831103488249	\N	\N	2026-06-24 16:20:31.103632+02	t
583	0	task	api-test-requirement-task-1782310831138708648	\N	\N	2026-06-24 16:20:31.138826+02	t
587	0	task	api-test-requirement-task-1782310831185622904	\N	\N	2026-06-24 16:20:31.185784+02	t
590	0	task	api-test-aggregate-parent-1782310831227078819	\N	\N	2026-06-24 16:20:31.227203+02	t
591	0	task	api-test-aggregate-child-1782310831232131320	\N	590	2026-06-24 16:20:31.232414+02	t
\.


--
-- Data for Name: task_phase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_phase (slug, priority) FROM stdin;
backlog	0
progress	1
review	2
staging	3
production	4
repair	5
\.


--
-- Data for Name: task_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_type (slug, priority) FROM stdin;
epic	0
feature	0
group	0
issue	0
spike	0
task	0
upgrade	0
\.


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.project_id_seq', 348, true);


--
-- Name: requirement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.requirement_id_seq', 395, true);


--
-- Name: task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_id_seq', 600, true);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: requirement_history requirement_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requirement_history
    ADD CONSTRAINT requirement_history_pkey PRIMARY KEY (id, version);


--
-- Name: requirement requirement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requirement
    ADD CONSTRAINT requirement_pkey PRIMARY KEY (id);


--
-- Name: task_history task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_pkey PRIMARY KEY (id, version);


--
-- Name: task_phase task_phase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_phase
    ADD CONSTRAINT task_phase_pkey PRIMARY KEY (slug);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: task_type task_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_type
    ADD CONSTRAINT task_type_pkey PRIMARY KEY (slug);


--
-- PostgreSQL database dump complete
--

\unrestrict 4dTX2Sq2fpKriwsWNTTmQ1tNAbFEbCWvBqaJfc7vbkcsEvvBpb3BGTN9JNRSrN3

